#!/usr/bin/env perl

use Cwd;
use File::Find;
use File::Spec;
use IO::File;
use Getopt::Long;
use strict;
use warnings;



my $cwd = getcwd();
my $fileName1 = shift;
my $fileName2 = shift;


open( IN1, "<$fileName1" ) or die "Unable to open $fileName1 for reading.\n";
open( IN2, "<$fileName2" ) or die "Unable to open $fileName2 for reading.\n";


open( OUT, ">combined.txt" ) or die "Unable to open l1.txt for writing.\n";

while (my $line = <IN1> ) {
	my @fields = split(/\s+/, $line);
	if (  $fields[0] < 0.5 ) {
	   print OUT "$fields[0]\t$fields[1]\n";
	}
}

while (my $line = <IN2> ) {
	my @fields = split(/\s+/, $line);
	if (  $fields[0] > 0.05 && $fields[0] < 0.4 ) {
	  $fields[0] += 0.45;
	  #$fields[1] += 0.01;
	  print OUT "$fields[0]\t$fields[1]\n";
        }
}
