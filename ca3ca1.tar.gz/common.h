#ifndef COMMON_H
#define COMMON_H
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include "loadParams.h"

//host-side
//row-major ordering. first index specifies row, 2nd specifies column
float big_in_pat[W1*W1];
float small_in_pat[W4*W4];
//device-side
float*  d_big_in_pat;
float*  d_small_in_pat;

//support variables associated with the network architecture
//potentially referenced by main,  interactions, anything on the C side

cellParamStruct layer1_params, layer2_params;
synParamStruct  syn_params_l1_l2, syn_params_common, syn_params_tii_to_lgn, syn_params_trn_to_tii, syn_params_ho_v2, syn_params_l4_v2, syn_params_v2s_v2p;

cell_switchesStruct cell_switches1, cell_switches2;
syn_switchesStruct s_iB, s_iS, s_latB, s_latS, s_b2s, s_iCA3, s_s2b, s_ca3lat, s_ca32ca1, s_s2br;

typedef struct layer{
    //0:vm   1:isyn
    int win[3];    
    GLuint  pbo[2];
    GLuint  tex[2];
    struct cudaGraphicsResource *cuda_pbo_resource[2];
    uchar4 *vm ;
    uchar4 *isyn;
    uchar4 *dummy1, *dummy2;
    lif_data_type *cells;  //doesn't work for some reason
} layer ;
layer A_layers[100]; //CA1 primary (big) path
layer B_layers[100]; //CA1 tag (small) path
layer C_layers[100]; //CA3 path
// texture and pixel objects

//These are cudaMalloced to create an array of lif_data_types
lif_data_type *A_cellLayer1;   //input layer to CA1 primary
lif_data_type *A_cellLayer2;   // CA1 primary cell layer
lif_data_type *B_cellLayer1;   //input layer to CA1 tag layer
lif_data_type *B_cellLayer2;   //CA1 tag layer
lif_data_type *C_cellLayer1;   //input layer to CA3 primary
lif_data_type *C_cellLayer2;   // CA3 primary cell layer.  CA3 does not have a tag layer


//V2
L1_synapse_data_type *A_synapse_i_pc; //A input to pattern-completion layer
P_synapse_data_type  *A_synapse_pc_lateral; //A pattern-completion layer lateral connections
P_synapse_data_type *b2s_synapse; //big array onto small array
P_synapse_data_type *s2br_synapse; //big array onto small array reverse
P_synapse_data_type *s2b_synapse; //small array onto big array

L1_synapse_data_type *B_synapse_i_pc; //B input to pattern-completion layer
P_synapse_data_type  *B_synapse_pc_lateral; //B pattern-completion layer lateral connections

L1_synapse_data_type *C_synapse_i_pc; //CA3 input to pattern-completion layer
P_synapse_data_type  *C_synapse_pc_lateral; //CA3 pattern-completion layer lateral connections
P_synapse_data_type *ca3_2_ca1_synapse; //CA3 PC layer to CA1 PC layer path

void initGLUT(int *argc, char **argv ) {
  glutInit(argc, argv);
  glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE);
 
  //Scaling up to a larger window size can be done here.
  //if Size is to be scaled, an equivalent change is need for mouse location calculation.

  int Yrow0 = 600; 
  int Yrow1 = 900; 
  int Yrow2 = Yrow1+300;
  int Yrow2b = Yrow2+200;
  int LeftEdge = 100;

  //A after B, A displays
  //B after A, B displays

  glutInitWindowSize(W4, W4);
  glutInitWindowPosition(LeftEdge + 170, Yrow2);  
  B_layers[1].win[1] = glutCreateWindow("Window 4"); //CA1 tag stimulus pattern Isyn
  glutInitWindowPosition(LeftEdge + 470, Yrow2);  
  B_layers[1].win[0] = glutCreateWindow("Window 4"); //CA1 tag stimulus pattern vm
  glutInitWindowPosition(LeftEdge + 770, Yrow2);  //CA1 tag array vm
  B_layers[2].win[0] = glutCreateWindow("Window 4");

  glutInitWindowSize(W1, W1);
  glutInitWindowPosition(LeftEdge + 70, Yrow1);
  A_layers[1].win[1] = glutCreateWindow("Window 1");  //CA1 primary input layer Isyn
  glutInitWindowPosition(LeftEdge + 370, Yrow1);
  A_layers[1].win[0] = glutCreateWindow("Window 1");  //CA1 primary input layer Vm
  glutInitWindowPosition(LeftEdge + 670, Yrow1);
  A_layers[2].win[0] = glutCreateWindow("Window 2");  //CA1 primary pattern completion layer Vm
						      
  glutInitWindowPosition(LeftEdge + 1100, Yrow2b);
  A_layers[2].win[1] = glutCreateWindow("Window 2");  //CA1 primary pattern completion layer Isyn

  glutInitWindowPosition(LeftEdge + 1170, Yrow2b );  //CA1 tag array isyn
  B_layers[2].win[1] = glutCreateWindow("Window 4");


  //CA3
  glutInitWindowSize(W1, W1);
  glutInitWindowPosition(LeftEdge + 70, Yrow0);
  C_layers[1].win[1] = glutCreateWindow("Window 1");  //CA3 input layer Isyn
  glutInitWindowPosition(LeftEdge + 370, Yrow0);
  C_layers[1].win[0] = glutCreateWindow("Window 1");  //CA3 input layer Vm
  glutInitWindowPosition(LeftEdge + 670, Yrow0);
  C_layers[2].win[0] = glutCreateWindow("Window 2");  //CA3 pattern completion layer Vm
  glutInitWindowPosition(LeftEdge + 1000, Yrow0);
  C_layers[2].win[1] = glutCreateWindow("Window 2");  //CA3 pattern completion layer Isyn
						      //CA3 does not have a tag layer

  glewInit();
}



void resetNetwork() {
  char fileName[100];
  int retCode;
  strcpy(fileName, "cell_layer_params.txt");
  retCode = readCellParamsFromFile( fileName, &layer1_params );
  resetCells( A_cellLayer1, W1, layer1_params, 1 );
  resetCells(A_cellLayer2, W2, layer1_params, 2 );  
  resetCells( B_cellLayer1, W4, layer1_params, 2 );
  resetCells( B_cellLayer2, W4, layer1_params, 2 );

  resetSnaps(  A_synapse_i_pc,   W1, W1, syn_params_l1_l2,  1 );
  resetSnapsP( A_synapse_pc_lateral,   W1, W1, syn_params_l1_l2,  1 );

  resetSnaps(  B_synapse_i_pc,   W4, W4, syn_params_l1_l2,  1 );
  resetSnapsP( B_synapse_pc_lateral,   W4, W4, syn_params_l1_l2,  1 );

  resetCells( C_cellLayer1, W1, layer1_params, 2 );
  resetCells( C_cellLayer2, W1, layer1_params, 2 );
  resetSnaps(  C_synapse_i_pc,   W1, W1, syn_params_l1_l2,  1 );
  resetSnapsP( C_synapse_pc_lateral,   W1, W1, syn_params_l1_l2,  1 );
  resetSnapsP( ca3_2_ca1_synapse,   W1, W1, syn_params_l1_l2,  1 );

}


#endif
