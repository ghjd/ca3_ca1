#ifndef GEN_PATS_H
#define GEN_PATS_H
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#define PSTIM 0.5e-9

void genPats( float * pattern, float * d_pattern, lif_data_type* cell_layer, int width, int sel, bool cue  ) {  //cue:0  complete pattern  cue:1 apprporiate segment for cuing a memory
   printf("[INFO]GenPats Width=%d\tSel=%d\tCue=%s\n", width, sel, cue ? "true" : "false" );
   int row, col, pat;
   int x0, y0, P, R; 
   int x1, y1, run;
   float slope ;
   int inRange, onLine, rise, yPrime;
   int xz, yz;  //use these as the root location for a drawing
     for( row = 0; row < width; row++){
       for( col = 0; col < width; col++){
	 //two commonly used coordinates, anchored at the center of the array
	 int x = row - width/2;
	 int y = col - width/2;
	 pattern[width* row + col] = 0.0; //initialize to zero, set as necessary below
	 //BAR_WIDTH is narrow access
	 //BAR_HEIGHT is long access
         switch ( sel ) {
           case 0:  //empty
	       break;
           case 1:  //spot in the center
	       if ( abs(x) < 2 && abs(y) < 2 ) { pattern[width* row + col] = PSTIM; }
	       if ( cue ) { if ( abs(x) < 2 && abs(y) < 2 ) { pattern[width* row + col] = PSTIM; }}
	       break;
           case 5:  //horizontal bar through h/2
	       if ( abs(x) < BAR_WIDTH && abs(y) < BAR_HEIGHT ) { pattern[width* row + col] = PSTIM; }
	       if ( cue ) { if ( col > 55 ) {  pattern[width* row + col] = 0; } }
	       break;
           case 6:  //vertical bar through w/2
	       if ( abs( col - width/2) < BAR_WIDTH && abs(row-width/2) < BAR_HEIGHT ) { pattern[width* row + col] = PSTIM; }
	       if ( cue ) { if ( row > 55 ) {  pattern[width* row + col] = 0; } }
	       break;
           case 7:  //diagonal \ bar
	         if ( abs(x - y) < BAR_WIDTH && abs(x) < BAR_HEIGHT ) { pattern[width* row + col] = PSTIM; }
	         if ( cue ) { if ( col > 55 ) { pattern[width* row + col] = 0; } }
	       break;
           case 8:  //diagonal / bar
	         if ( abs(x + y) < BAR_WIDTH && abs(x) < BAR_HEIGHT ) { pattern[width* row + col] = PSTIM; }
	         if ( cue ) { if ( col > 55 ) { pattern[width* row + col] = 0; } }
	       break;
           case 9:  //horizontal sin wave
	       if ((abs(x + 8*cos( 2*3.1415926 * (float)col/75) - 75)) < BAR_WIDTH && (abs(y) < BAR_HEIGHT )) { pattern[width* row + col] = PSTIM; }
	       if ((abs(x + 8*cos( 2*3.1415926 * (float)col/75) + 75)) < BAR_WIDTH && (abs(y) < BAR_HEIGHT )) { pattern[width* row + col] = PSTIM; }
	       if ( cue ) { if ( row < width/2 && col > 55 ) {  pattern[width* row + col] = 0; } }
	       if ( cue ) { if ( row > width/2 && col < 245 ) {  pattern[width* row + col] = 0; } }
	       break;
           case 10:  //vertical sin wave
	       if ((abs(y + 8*cos( 2*3.1415926 * (float)row/75) - 75)) < BAR_WIDTH && (abs(x) < BAR_HEIGHT )) { pattern[width* row + col] = PSTIM; }
	       if ((abs(y + 8*cos( 2*3.1415926 * (float)row/75) + 75)) < BAR_WIDTH && (abs(x) < BAR_HEIGHT )) { pattern[width* row + col] = PSTIM; }
	       if ( cue ) { if ( col < width/2 && row > 55 ) {  pattern[width* row + col] = 0; } }
	       if ( cue ) { if ( col > width/2 && row < 245 ) {  pattern[width* row + col] = 0; } }
	       break;
	       //these get used in the small array.  Not sure if they work in the big array, haven't tried.
           case 11:  //short vertical line through center
	       if ( abs( col - width/2 - 4) < BAR_WIDTH && abs(row-width/2) < 50 ) { pattern[width* row + col] = PSTIM; }
	       if ( cue ) { if ( row > 12 ) {  pattern[width* row + col] = 0; } }
	       break;
           case 12:  //two short vertical lines 
	       if ( abs( col - width/2 - 20) < BAR_WIDTH && abs(row-width/2) < 51 ) { pattern[width* row + col] = PSTIM; }
	       if ( abs( col - width/2 + 20) < BAR_WIDTH && abs(row-width/2) < 51 ) { pattern[width* row + col] = PSTIM; }
	       if ( cue ) { if ( row > 12 ) {  pattern[width* row + col] = 0; } }
	       break;
           case 13:  //three short vertical lines 
	       if ( abs( col - width/2 - 30) < BAR_WIDTH && abs(row-width/2) < 51 ) { pattern[width* row + col] = PSTIM; }
	       if ( abs( col - width/2 + 30)  < BAR_WIDTH && abs(row-width/2) < 51 ) { pattern[width* row + col] = PSTIM; }
	       if ( abs( col - width/2 + 4)   < BAR_WIDTH && abs(row-width/2) < 51 ) { pattern[width* row + col] = PSTIM; }
	       if ( cue ) { if ( row > 12 ) {  pattern[width* row + col] = 0; } }
	       break;
           case 14:  //short horizontal line through center
	       if ( abs( row - width/2 - 4) < BAR_WIDTH && abs(col-width/2) < 51 ) { pattern[width* row + col] = PSTIM; }
	       if ( cue ) { if ( col > 12 ) {  pattern[width* row + col] = 0; } }
	       break;
           case 15:  //two short horizontal lines 
	       if ( abs( row - width/2 - 20)  < BAR_WIDTH && abs(col-width/2) < 51 ) { pattern[width* row + col] = PSTIM; }
	       if ( abs( row - width/2 + 20)  < BAR_WIDTH && abs(col-width/2) < 51 ) { pattern[width* row + col] = PSTIM; }
	       if ( cue ) { if ( col > 12 ) {  pattern[width* row + col] = 0; } }
	       break;
           case 16:  //three short horizontal lines 
	       if ( abs( row - width/2 - 30)  < BAR_WIDTH && abs(col-width/2) < 51 ) { pattern[width* row + col] = PSTIM; }
	       if ( abs( row - width/2 + 30)  < BAR_WIDTH && abs(col-width/2) < 51 ) { pattern[width* row + col] = PSTIM; }
	       if ( abs( row - width/2 + 4)   < BAR_WIDTH && abs(col-width/2) < 51 ) { pattern[width* row + col] = PSTIM; }
	       if ( cue ) { if ( col > 12 ) {  pattern[width* row + col] = 0; } }
	       break;
           case 200:  //a cat in upper left
	       //compensated coordinates
               xz = 65; yz = 240; 
	       x=col; y=299 - row;
	       //the circles for head and eyes
	       R = 30;  //center-location and size
	       x0 = xz; y0 = yz;
	       if ( !cue ) {
	           P = int( sqrt( (x - x0) * (x - x0)  + (y - y0) * (y - y0) ));
	           if ( P >= R && P < R+2) { pattern[width* row + col] = PSTIM; }
                   x0 = xz-10; y0 = yz+13; R = 6;
	           P = int( sqrt( (x - x0) * (x - x0)  + (y - y0) * (y - y0) ));
	           if ( P >= R && P < R+2) { pattern[width* row + col] = PSTIM; }
	           x0 = xz+10; y0 = yz+13; R = 6;
	           P = int( sqrt( (x - x0) * (x - x0)  + (y - y0) * (y - y0) ));
	           if ( P >= R && P < R+2) { pattern[width* row + col] = PSTIM; }
	           //left whiskers
	           x0 = xz-45; x1 = xz-20; y0 = yz-5; y1 = yz-5; //horiz
	           slope = (float)(y1 - y0)/(float)(x1-x0); inRange = (x >= x0 & x <= x1) & (y >= y0 & y <= y1) ? 1 : 0;
	           yPrime = y0 + (x-x0)*slope; onLine = y >= yPrime & y <= yPrime + 4 ? 1 : 0;
	           if (inRange & onLine) { pattern[width* row + col] = PSTIM; }
	           x0 = xz-45; x1 = xz-20; y0 = yz+8; y1 = yz;//upper
	           slope = (float)(y1 - y0)/(float)(x1-x0); inRange = (x >= x0 & x <= x1) & (y >= y1 & y <= y0) ? 1 : 0;//y gt/lt reverse if y1 < y0
	           yPrime = y0 + (x-x0)*slope; onLine = y >= yPrime & y <= yPrime + 2 ? 1 : 0;
	           if (inRange & onLine) { pattern[width* row + col] = PSTIM; }
	           x0 = xz-45; x1 = xz-20; y0 = yz-20; y1 = yz-10;//lower
	           slope = (float)(y1 - y0)/(float)(x1-x0); inRange = (x >= x0 & x <= x1) & (y >= y0 & y <= y1) ? 1 : 0;
	           yPrime = y0 + (x-x0)*slope; onLine = y >= yPrime & y <= yPrime + 2 ? 1 : 0;
	           if (inRange & onLine) { pattern[width* row + col] = PSTIM; }
	           //right whiskers
	           x0 = xz+25; x1 = xz+45; y0 = yz-5; y1 = yz-5; //horiz
	           slope = (float)(y1 - y0)/(float)(x1-x0); inRange = (x >= x0 & x <= x1) & (y >= y0 & y <= y1) ? 1 : 0;
	           yPrime = y0 + (x-x0)*slope; onLine = y >= yPrime & y <= yPrime + 4 ? 1 : 0;
	           if (inRange & onLine) { pattern[width* row + col] = PSTIM; }
	           x0 = xz+25; x1 = xz+45; y0 = yz; y1 = yz+8;//upper
	           slope = (float)(y1 - y0)/(float)(x1-x0); inRange = (x >= x0 & x <= x1) & (y >= y0 & y <= y1) ? 1 : 0;//y gt/lt reverse if y1 < y0
	           yPrime = y0 + (x-x0)*slope; onLine = y >= yPrime & y <= yPrime + 2 ? 1 : 0;
	           if (inRange & onLine) { pattern[width* row + col] = PSTIM; }
	           x0 = xz+25; x1 = xz+45; y0 = yz-10; y1 = yz-20;//upper
	           slope = (float)(y1 - y0)/(float)(x1-x0); inRange = (x >= x0 & x <= x1) & (y >= y1 & y <= y0) ? 1 : 0;
	           yPrime = y0 + (x-x0)*slope; onLine = y >= yPrime & y <= yPrime + 2 ? 1 : 0;
	           if (inRange & onLine) { pattern[width* row + col] = PSTIM; }
	           //right ear
	           x0 = xz+16; x1 = xz+22; y0 = yz+28; y1 = yz+42;
	           slope = (float)(y1 - y0)/(float)(x1-x0); inRange = (x >= x0 & x <= x1) & (y >= y0 & y <= y1) ? 1 : 0;
	           yPrime = y0 + (x-x0)*slope; onLine = y >= yPrime & y <= yPrime + 4 ? 1 : 0;
	           if (inRange & onLine) { pattern[width* row + col] = PSTIM; }
	           x0 = xz+22; x1 = xz+26; y0 = yz+42; y1 = yz+20;
	           slope = (float)(y1 - y0)/(float)(x1-x0); inRange = (x >= x0 & x <= x1) & (y >= y1 & y <= y0) ? 1 : 0;//y gt/lt reverse if y1 < y0
	           yPrime = y0 + (x-x0)*slope; onLine = y >= yPrime & y <= yPrime + 4 ? 1 : 0;
	           if (inRange & onLine) { pattern[width* row + col] = PSTIM; }
               }
	       //left ear
	       x0 = xz-22; x1 = xz-16; y0 = yz+20; y1 = yz+42;
	       slope = (float)(y1 - y0)/(float)(x1-x0); inRange = (x >= x0 & x <= x1) & (y >= y0 & y <= y1) ? 1 : 0;
	       yPrime = y0 + (x-x0)*slope; onLine = y >= yPrime & y <= yPrime + 4 ? 1 : 0;
	       if (inRange & onLine) { pattern[width* row + col] = PSTIM; }
	       x0 = xz-16; x1 = xz-10; y0 = yz+42; y1 = yz+28;
	       slope = (float)(y1 - y0)/(float)(x1-x0); inRange = (x >= x0 & x <= x1) & (y >= y1 & y <= y0) ? 1 : 0;//y gt/lt reverse if y1 < y0
	       yPrime = y0 + (x-x0)*slope; onLine = y >= yPrime & y <= yPrime + 4 ? 1 : 0;
	       if (inRange & onLine) { pattern[width* row + col] = PSTIM; }
               R = 6;  //center-location and size
               x0 = 150; y0 = 144;
               P = int( sqrt( (x - x0) * (x - x0)  + (y - y0) * (y - y0) ));
               if ( P >= R && P < R+2) { pattern[width* row + col] = PSTIM; }

	       break;
           case 201:  //a cat at lower right
               xz = 235; yz = 40;
               x=col; y=299 - row;
               //the circles for head and eyes
	       if ( !cue ) {
                   R = 30;  //center-location and size
                   x0 = xz; y0 = yz;
                   P = int( sqrt( (x - x0) * (x - x0)  + (y - y0) * (y - y0) ));
                   if ( P >= R && P < R+2) { pattern[width* row + col] = PSTIM; }
                   x0 = xz-10; y0 = yz+13; R = 6;
                   P = int( sqrt( (x - x0) * (x - x0)  + (y - y0) * (y - y0) ));
                   if ( P >= R && P < R+2) { pattern[width* row + col] = PSTIM; }
                   x0 = xz+10; y0 = yz+13; R = 6;
                   P = int( sqrt( (x - x0) * (x - x0)  + (y - y0) * (y - y0) ));
                   if ( P >= R && P < R+2) { pattern[width* row + col] = PSTIM; }
                   //left whiskers
                   x0 = xz-45; x1 = xz-20; y0 = yz-5; y1 = yz-5; //horiz
                   slope = (float)(y1 - y0)/(float)(x1-x0); inRange = (x >= x0 & x <= x1) & (y >= y0 & y <= y1) ? 1 : 0;
                   yPrime = y0 + (x-x0)*slope; onLine = y >= yPrime & y <= yPrime + 4 ? 1 : 0;
                   if (inRange & onLine) { pattern[width* row + col] = PSTIM; }
                   x0 = xz-45; x1 = xz-20; y0 = yz+8; y1 = yz;//upper
                   slope = (float)(y1 - y0)/(float)(x1-x0); inRange = (x >= x0 & x <= x1) & (y >= y1 & y <= y0) ? 1 : 0;//y gt/lt reverse if y1 < y0
                   yPrime = y0 + (x-x0)*slope; onLine = y >= yPrime & y <= yPrime + 2 ? 1 : 0;
                   if (inRange & onLine) { pattern[width* row + col] = PSTIM; }
                   x0 = xz-45; x1 = xz-20; y0 = yz-20; y1 = yz-10;//lower
                   slope = (float)(y1 - y0)/(float)(x1-x0); inRange = (x >= x0 & x <= x1) & (y >= y0 & y <= y1) ? 1 : 0;
                   yPrime = y0 + (x-x0)*slope; onLine = y >= yPrime & y <= yPrime + 2 ? 1 : 0;
                   if (inRange & onLine) { pattern[width* row + col] = PSTIM; }
                   //right whiskers
                   x0 = xz+25; x1 = xz+45; y0 = yz-5; y1 = yz-5; //horiz
                   slope = (float)(y1 - y0)/(float)(x1-x0); inRange = (x >= x0 & x <= x1) & (y >= y0 & y <= y1) ? 1 : 0;
                   yPrime = y0 + (x-x0)*slope; onLine = y >= yPrime & y <= yPrime + 4 ? 1 : 0;
                   if (inRange & onLine) { pattern[width* row + col] = PSTIM; }
                   x0 = xz+25; x1 = xz+45; y0 = yz; y1 = yz+8;//upper
                   slope = (float)(y1 - y0)/(float)(x1-x0); inRange = (x >= x0 & x <= x1) & (y >= y0 & y <= y1) ? 1 : 0;//y gt/lt reverse if y1 < y0
                   yPrime = y0 + (x-x0)*slope; onLine = y >= yPrime & y <= yPrime + 2 ? 1 : 0;
                   if (inRange & onLine) { pattern[width* row + col] = PSTIM; }
                   x0 = xz+25; x1 = xz+45; y0 = yz-10; y1 = yz-20;//upper
                   slope = (float)(y1 - y0)/(float)(x1-x0); inRange = (x >= x0 & x <= x1) & (y >= y1 & y <= y0) ? 1 : 0;
                   yPrime = y0 + (x-x0)*slope; onLine = y >= yPrime & y <= yPrime + 2 ? 1 : 0;
                   if (inRange & onLine) { pattern[width* row + col] = PSTIM; }
                   //right ear
                   x0 = xz+16; x1 = xz+22; y0 = yz+28; y1 = yz+42;
                   slope = (float)(y1 - y0)/(float)(x1-x0); inRange = (x >= x0 & x <= x1) & (y >= y0 & y <= y1) ? 1 : 0;
                   yPrime = y0 + (x-x0)*slope; onLine = y >= yPrime & y <= yPrime + 4 ? 1 : 0;
                   if (inRange & onLine) { pattern[width* row + col] = PSTIM; }
                   x0 = xz+22; x1 = xz+26; y0 = yz+42; y1 = yz+20;
                   slope = (float)(y1 - y0)/(float)(x1-x0); inRange = (x >= x0 & x <= x1) & (y >= y1 & y <= y0) ? 1 : 0;//y gt/lt reverse if y1 < y0
                   yPrime = y0 + (x-x0)*slope; onLine = y >= yPrime & y <= yPrime + 4 ? 1 : 0;
                   if (inRange & onLine) { pattern[width* row + col] = PSTIM; }
	       }
               //left ear
               x0 = xz-22; x1 = xz-16; y0 = yz+20; y1 = yz+42;
               slope = (float)(y1 - y0)/(float)(x1-x0); inRange = (x >= x0 & x <= x1) & (y >= y0 & y <= y1) ? 1 : 0;
               yPrime = y0 + (x-x0)*slope; onLine = y >= yPrime & y <= yPrime + 4 ? 1 : 0;
               if (inRange & onLine) { pattern[width* row + col] = PSTIM; }
               x0 = xz-16; x1 = xz-10; y0 = yz+42; y1 = yz+28;
               slope = (float)(y1 - y0)/(float)(x1-x0); inRange = (x >= x0 & x <= x1) & (y >= y1 & y <= y0) ? 1 : 0;//y gt/lt reverse if y1 < y0
               yPrime = y0 + (x-x0)*slope; onLine = y >= yPrime & y <= yPrime + 4 ? 1 : 0;
               if (inRange & onLine) { pattern[width* row + col] = PSTIM; }
               R = 6;  //center-location and size
               x0 = 150; y0 = 157;
               P = int( sqrt( (x - x0) * (x - x0)  + (y - y0) * (y - y0) ));
               if ( P >= R && P < R+2) { pattern[width* row + col] = PSTIM; }
	       break;
           case 202:  //a cheese upper-right
	       x=col; y=299 - row;
               xz = 210; yz = 220; //root coordinate
	       //left upwards diagonal
               x0 = xz; x1 = xz+30; y0 = yz+40; y1 = yz+60; //upwards diag
               slope = (float)(y1 - y0)/(float)(x1-x0); inRange = (x >= x0 & x <= x1) & (y >= y0 & y <= y1) ? 1 : 0;
               yPrime = y0 + (x-x0)*slope; onLine = y >= yPrime & y <= yPrime + 4 ? 1 : 0;
               if (inRange & onLine) { pattern[width* row + col] = PSTIM; }
	       if ( !cue ) {
                   //left vertical edge
                   x0 = xz; x1 = xz; y0 = yz; y1 = yz+40;
                   if (x >=x0 & x <= x0+2 & y >= y0 & y <= y1 ) { pattern[width* row + col] = PSTIM; }
	           //right vertical edge
                   x0 = xz+70; x1 = xz+70; y0 = yz-15; y1 = yz+25;
                   if (x >=x0 & x <= x0+2 & y >= y0 & y <= y1 ) { pattern[width* row + col] = PSTIM; }
	           //lower diagonal
                   x0 = xz; x1 = xz+70; y0 = yz; y1 = yz-15; //downward diag
                   slope = (float)(y1 - y0)/(float)(x1-x0); inRange = (x >= x0 & x <= x1) & (y >= y1 & y <= y0) ? 1 : 0;
                   yPrime = y0 + (x-x0)*slope; onLine = y >= yPrime & y <= yPrime + 4 ? 1 : 0;
                   if (inRange & onLine) { pattern[width* row + col] = PSTIM; }
	           //upper diagonal
                   x0 = xz; x1 = xz+70; y0 = yz+40; y1 = yz+25; //downward diag
                   slope = (float)(y1 - y0)/(float)(x1-x0); inRange = (x >= x0 & x <= x1) & (y >= y1 & y <= y0) ? 1 : 0;
                   yPrime = y0 + (x-x0)*slope; onLine = y >= yPrime & y <= yPrime + 4 ? 1 : 0;
                   if (inRange & onLine) { pattern[width* row + col] = PSTIM; }
	           //upper downwards diagonal
                   x0 = xz+30; x1 = xz+72; y0 = yz+60; y1 = yz+25; //downward diag
                   slope = (float)(y1 - y0)/(float)(x1-x0); inRange = (x >= x0 & x <= x1) & (y >= y1 & y <= y0) ? 1 : 0;
                   yPrime = y0 + (x-x0)*slope; onLine = y >= yPrime & y <= yPrime + 4 ? 1 : 0;
                   if (inRange & onLine) { pattern[width* row + col] = PSTIM; }
	           //some holes, it's a swiss cheese!
                   R = 5;  //center-location and size
                   x0 = xz+20; y0 = yz+20;
                   P = int( sqrt( (x - x0) * (x - x0)  + (y - y0) * (y - y0) ));
                   if ( P >= R && P < R+2) { pattern[width* row + col] = PSTIM; }
                   R = 3;  //center-location and size
                   x0 = xz+50; y0 = yz+10;
                   P = int( sqrt( (x - x0) * (x - x0)  + (y - y0) * (y - y0) ));
                   if ( P >= R && P < R+2) { pattern[width* row + col] = PSTIM; }
	       }
	       //central circle
               R = 6;  //center-location and size
               x0 = 157; y0 = 150;
               P = int( sqrt( (x - x0) * (x - x0)  + (y - y0) * (y - y0) ));
               if ( P >= R && P < R+2) { pattern[width* row + col] = PSTIM; }
	       break;
           case 203:  //a cheese lower left
               x=col; y=299 - row;
               xz = 20; yz = 20; //root coordinate
               //left upwards diagonal
               x0 = xz; x1 = xz+30; y0 = yz+40; y1 = yz+60; //upwards diag
               slope = (float)(y1 - y0)/(float)(x1-x0); inRange = (x >= x0 & x <= x1) & (y >= y0 & y <= y1) ? 1 : 0;
               yPrime = y0 + (x-x0)*slope; onLine = y >= yPrime & y <= yPrime + 4 ? 1 : 0;
               if (inRange & onLine) { pattern[width* row + col] = PSTIM; }
	       if ( !cue ) {
                   //left vertical edge
                   x0 = xz; x1 = xz; y0 = yz; y1 = yz+40;
                   if (x >=x0 & x <= x0+2 & y >= y0 & y <= y1 ) { pattern[width* row + col] = PSTIM; }
                   //right vertical edge
                   x0 = xz+70; x1 = xz+70; y0 = yz-15; y1 = yz+25;
                   if (x >=x0 & x <= x0+2 & y >= y0 & y <= y1 ) { pattern[width* row + col] = PSTIM; }
                   //lower diagonal
                   x0 = xz; x1 = xz+70; y0 = yz; y1 = yz-15; //downward diag
                   slope = (float)(y1 - y0)/(float)(x1-x0); inRange = (x >= x0 & x <= x1) & (y >= y1 & y <= y0) ? 1 : 0;
                   yPrime = y0 + (x-x0)*slope; onLine = y >= yPrime & y <= yPrime + 4 ? 1 : 0;
                   if (inRange & onLine) { pattern[width* row + col] = PSTIM; }
                   //upper diagonal
                   x0 = xz; x1 = xz+70; y0 = yz+40; y1 = yz+25; //downward diag
                   slope = (float)(y1 - y0)/(float)(x1-x0); inRange = (x >= x0 & x <= x1) & (y >= y1 & y <= y0) ? 1 : 0;
                   yPrime = y0 + (x-x0)*slope; onLine = y >= yPrime & y <= yPrime + 4 ? 1 : 0;
                   if (inRange & onLine) { pattern[width* row + col] = PSTIM; }
                   //upper downwards diagonal
                   x0 = xz+30; x1 = xz+72; y0 = yz+60; y1 = yz+25; //downward diag
                   slope = (float)(y1 - y0)/(float)(x1-x0); inRange = (x >= x0 & x <= x1) & (y >= y1 & y <= y0) ? 1 : 0;
                   yPrime = y0 + (x-x0)*slope; onLine = y >= yPrime & y <= yPrime + 4 ? 1 : 0;
                   if (inRange & onLine) { pattern[width* row + col] = PSTIM; }
                   //some holes, it's a swiss cheese!
                   R = 5;  //center-location and size
                   x0 = xz+20; y0 = yz+20;
                   P = int( sqrt( (x - x0) * (x - x0)  + (y - y0) * (y - y0) ));
                   if ( P >= R && P < R+2) { pattern[width* row + col] = PSTIM; }
                   R = 3;  //center-location and size
                   x0 = xz+50; y0 = yz+10;
                   P = int( sqrt( (x - x0) * (x - x0)  + (y - y0) * (y - y0) ));
                   if ( P >= R && P < R+2) { pattern[width* row + col] = PSTIM; }
	       }
	       //central circle
               R = 6;  //center-location and size
               x0 = 143; y0 = 150;
               P = int( sqrt( (x - x0) * (x - x0)  + (y - y0) * (y - y0) ));
               if ( P >= R && P < R+2) { pattern[width* row + col] = PSTIM; }
               break;
	       
	       //shorter fatter line segments to be used in the big array for a path sequence
	       //uppwards right path
	       //upper-left:(0,0) lower-left:(width, 0) upper-right:(0,width)  lower-right:(width, width)
	       //back-slash from UL horiz (0,0) to (300, 300)
	       // s2br S   101 102 103 104 105 106 107 108 109     -1 state3 sequence
	       // s2b  S       100 101 102 103 104 105 106 107 108 +1 state2 sequence
	       //      B   20  21  22  23  24  25  26  27  28  29   
	       // b2s  S   100 101 102 103 104 105 106 107 108 109  =  state1 sequence
           case 20:  if ( (row > 120 && row < 148) &&  ( col > 150 && col < 155 )) { pattern[width* row + col] = PSTIM; } break; //first&center pattern of up/left path
           case 21:  if ( (row > 120 && row < 125) &&  ( col > 120 && col < 150 )) { pattern[width* row + col] = PSTIM; } break;
           case 22:  if ( (row > 90 && row < 120) &&  ( col > 120 && col < 125 )) { pattern[width* row + col] = PSTIM; } break;
           case 23:  if ( (row > 90 && row < 95) &&  ( col > 90 && col < 120 )) { pattern[width* row + col] = PSTIM; } break;
           case 24:  if ( (row > 60 && row < 90) &&  ( col > 90 && col < 95 )) { pattern[width* row + col] = PSTIM; } break;
           case 25:  if ( (row > 60 && row < 65) &&  ( col > 60 && col < 90 )) { pattern[width* row + col] = PSTIM; } break;
           case 26:  if ( (row > 30 && row < 60) &&  ( col > 60 && col < 65 )) { pattern[width* row + col] = PSTIM; } break;
           case 27:  if ( (row > 30 && row < 35) &&  ( col > 30 && col < 60 )) { pattern[width* row + col] = PSTIM; } break;
           case 28:  if ( (row > 0 && row < 30)  &&  ( col > 30 && col < 35 )) { pattern[width* row + col] = PSTIM; } break; //v//v//v
           case 29:  if ( (row >  1 && row < 6)  &&  ( col > 1  && col < 30 )) { pattern[width* row + col] = PSTIM; } break; //h
			     
	       //down & right to LR from center
	       // s2br S   131 132 133 134 135 136 137 138 139     -1 state3 sequence
	       // s2b  S       130 131 132 133 134 135 136 137 138 +1 state2 sequence
	       //      B   30  31  32  33  34  35  36  37  38  39   
	       // b2s  S   130 131 132 133 134 135 136 137 138 139  =  state1 sequence
           case 30:  if ( (row > 150 && row < 155) &&  ( col > 152 && col < 180 )) { pattern[width* row + col] = PSTIM; } break; //h first&center pattern of down/right path
           case 31:  if ( (row > 150 && row < 180) &&  ( col > 180 && col < 185 )) { pattern[width* row + col] = PSTIM; } break; //v
           case 32:  if ( (row > 180 && row < 185) &&  ( col > 180 && col < 210 )) { pattern[width* row + col] = PSTIM; } break;
           case 33:  if ( (row > 180 && row < 210) &&  ( col > 210 && col < 215 )) { pattern[width* row + col] = PSTIM; } break;
           case 34:  if ( (row > 210 && row < 215) &&  ( col > 210 && col < 240 )) { pattern[width* row + col] = PSTIM; } break;
           case 35:  if ( (row > 210 && row < 240) &&  ( col > 240 && col < 245 )) { pattern[width* row + col] = PSTIM; } break;
           case 36:  if ( (row > 240 && row < 245) &&  ( col > 240 && col < 270 )) { pattern[width* row + col] = PSTIM; } break;
           case 37:  if ( (row > 240 && row < 270) &&  ( col > 270 && col < 275 )) { pattern[width* row + col] = PSTIM; } break;
           case 38:  if ( (row > 270 && row < 275) &&  ( col > 270 && col < 299 )) { pattern[width* row + col] = PSTIM; } break;
           case 39:  if ( (row > 271 && row < 299) &&  ( col > 294 && col < 299 )) { pattern[width* row + col] = PSTIM; } break;

	       //down & left to LL from center
	       // s2br S   121 122 123 124 125 126 127 128 129     -1 state3 sequence
	       // s2b  S       120 121 122 123 124 125 126 127 128 +1 state2 sequence
	       //      B   40  41  42  43  44  45  46  47  48  49   
	       // b2s  S   120 121 122 123 124 125 126 127 128 129  =  state1 sequence
           case 40:  if ( (row > 152 && row < 180) &&  ( col > 150 && col < 155 )) { pattern[width* row + col] = PSTIM; } break; //first&center pattern of down/left path
           case 41:  if ( (row > 175 && row < 180) &&  ( col > 120 && col < 150 )) { pattern[width* row + col] = PSTIM; } break;
           case 42:  if ( (row > 180 && row < 210) &&  ( col > 120 && col < 125 )) { pattern[width* row + col] = PSTIM; } break;
           case 43:  if ( (row > 205 && row < 210) &&  ( col > 90 && col < 120 )) { pattern[width* row + col] = PSTIM; } break;
           case 44:  if ( (row > 210 && row < 240) &&  ( col > 90 && col < 95 )) { pattern[width* row + col] = PSTIM; } break;
           case 45:  if ( (row > 235 && row < 240) &&  ( col > 60 && col < 90 )) { pattern[width* row + col] = PSTIM; } break;
           case 46:  if ( (row > 240 && row < 270) &&  ( col > 60 && col < 65 )) { pattern[width* row + col] = PSTIM; } break;
           case 47:  if ( (row > 265 && row < 270) &&  ( col > 30 && col < 60 )) { pattern[width* row + col] = PSTIM; } break;
           case 48:  if ( (row > 270 && row < 300)  &&  ( col > 30 && col < 35 )) { pattern[width* row + col] = PSTIM; } break;  //v
           case 49:  if ( (row >  294 && row < 299)  &&  ( col > 1  && col < 30 )) { pattern[width* row + col] = PSTIM; } break; //h

	       //up & right from center
	       // s2br S   111 112 113 114 115 116 117 118 119     -1 state3 sequence
	       // s2b  S       110 111 112 113 114 115 116 117 118 +1 state2 sequence
	       //      B   50  51  52  53  54  55  56  57  58  59   
	       // b2s  S   110 111 112 113 114 115 116 117 118 119  =  state1 sequence
           case 50:  if ( (row > 144 && row < 149) &&  ( col > 152 && col < 180 )) { pattern[width* row + col] = PSTIM; } break; //first&center pattern of up/right path
           case 51:  if ( (row > 120 && row < 150) &&  ( col > 180 && col < 185 )) { pattern[width* row + col] = PSTIM; } break;
           case 52:  if ( (row > 115 && row < 120) &&  ( col > 180 && col < 210 )) { pattern[width* row + col] = PSTIM; } break;
           case 53:  if ( (row > 90 && row < 120) &&  ( col > 210 && col < 215 )) { pattern[width* row + col] = PSTIM; } break;
           case 54:  if ( (row > 85 && row < 90) &&  ( col > 210 && col < 240 )) { pattern[width* row + col] = PSTIM; } break;
           case 55:  if ( (row > 60 && row < 90) &&  ( col > 240 && col < 245 )) { pattern[width* row + col] = PSTIM; } break;
           case 56:  if ( (row > 55 && row < 60) &&  ( col > 240 && col < 270 )) { pattern[width* row + col] = PSTIM; } break;
           case 57:  if ( (row > 30 && row < 60) &&  ( col > 270 && col < 275 )) { pattern[width* row + col] = PSTIM; } break;
           case 58:  if ( (row > 25 && row < 30) &&  ( col > 273 && col < 297 )) { pattern[width* row + col] = PSTIM; } break;
           case 59:  if ( (row > 1 && row < 27) &&  ( col > 294 && col < 299 )) { pattern[width* row + col] = PSTIM; } break;


	       //100x100 coords center to upper-left tags.  First (center) segment is vertical  works with 29-20
           case 100:  if ( (row <= 49 && row >= 41) && (col <= 49 && col >=41) ) { pattern[width* row + col] = PSTIM; } break;  //29/28 u/l
           case 101:  if ( (row <= 39 && row >= 31) && (col <= 49 && col >=41) ) { pattern[width* row + col] = PSTIM; } break;  //28/27 l/u
           case 102:  if ( (row <= 39 && row >= 31) && (col <= 39 && col >=31) ) { pattern[width* row + col] = PSTIM; } break;  // 27/26 u/l
           case 103:  if ( (row <= 29 && row >= 21) && (col <= 39 && col >=31) ) { pattern[width* row + col] = PSTIM; } break;  // 26/25 
           case 104:  if ( (row <= 29 && row >= 21) && (col <= 29 && col >=21) ) { pattern[width* row + col] = PSTIM; } break;  // 25/24 
           case 105:  if ( (row <= 19 && row >= 11) && (col <= 29 && col >=21) ) { pattern[width* row + col] = PSTIM; } break;  // 24/23 
           case 106:  if ( (row <= 19 && row >= 11) && (col <= 19 && col >=11) ) { pattern[width* row + col] = PSTIM; } break;  // 23/22 
           case 107:  if ( (row <= 9  && row >= 1)  && (col <= 19 && col >=11) ) { pattern[width* row + col] = PSTIM; } break;  // 22/21 
           case 108:  if ( (row <= 9  && row >= 1)  && (col <= 9  && col >=1 ) ) { pattern[width* row + col] = PSTIM; } break;  // 21/20 
           case 109:  if ( (row <= 19  && row >= 11)  && (col <= 9 && col >=1) ) { pattern[width* row + col] = PSTIM; } break;  // 20/21 
																
	       //100x100 coords center to upper-righ tags.  First (center) segment is horizontal  works with 50-59
           case 110:  if ( (row <= 49 && row >= 41) && (col <= 59 && col >=51) ) { pattern[width* row + col] = PSTIM; } break;  //
           case 111:  if ( (row <= 49 && row >= 41) && (col <= 69 && col >=61) ) { pattern[width* row + col] = PSTIM; } break;  //
           case 112:  if ( (row <= 39 && row >= 31) && (col <= 69 && col >=61) ) { pattern[width* row + col] = PSTIM; } break;  //
           case 113:  if ( (row <= 39 && row >= 31) && (col <= 79 && col >=71) ) { pattern[width* row + col] = PSTIM; } break;  //
           case 114:  if ( (row <= 29 && row >= 21) && (col <= 79 && col >=71) ) { pattern[width* row + col] = PSTIM; } break;  //
           case 115:  if ( (row <= 29 && row >= 21) && (col <= 89 && col >=81) ) { pattern[width* row + col] = PSTIM; } break;  //
           case 116:  if ( (row <= 19 && row >= 11) && (col <= 89 && col >=81) ) { pattern[width* row + col] = PSTIM; } break;  //
           case 117:  if ( (row <= 19 && row >= 11) && (col <= 99 && col >=91) ) { pattern[width* row + col] = PSTIM; } break;  //
           case 118:  if ( (row <=  9 && row >=  1) && (col <= 99 && col >=91) ) { pattern[width* row + col] = PSTIM; } break;  //
           case 119:  if ( (row <= 19 && row >= 11) && (col <= 99 && col >=91) ) { pattern[width* row + col] = PSTIM; } break;  //
															
	       //100x100 coords center to lower-left tags.  First (center) segment is vertical  works with  49-40
           case 120:  if ( (row <= 59 && row >= 51) && (col <= 49 && col >=41) ) { pattern[width* row + col] = PSTIM; } break;  
           case 121:  if ( (row <= 69 && row >= 61) && (col <= 49 && col >=41) ) { pattern[width* row + col] = PSTIM; } break;  
           case 122:  if ( (row <= 69 && row >= 61) && (col <= 39 && col >=31) ) { pattern[width* row + col] = PSTIM; } break; 
           case 123:  if ( (row <= 79 && row >= 71) && (col <= 39 && col >=31) ) { pattern[width* row + col] = PSTIM; } break; 
           case 124:  if ( (row <= 79 && row >= 71) && (col <= 29 && col >=21) ) { pattern[width* row + col] = PSTIM; } break; 
           case 125:  if ( (row <= 89 && row >= 81) && (col <= 29 && col >=21) ) { pattern[width* row + col] = PSTIM; } break;  
           case 126:  if ( (row <= 89 && row >= 81) && (col <= 19 && col >=11) ) { pattern[width* row + col] = PSTIM; } break;  
           case 127:  if ( (row <= 99 && row >= 91) && (col <= 19 && col >=11) ) { pattern[width* row + col] = PSTIM; } break;  
           case 128:  if ( (row <= 99 && row >= 91) && (col <= 9  && col >=1 ) ) { pattern[width* row + col] = PSTIM; } break;  
           case 129:  if ( (row <= 89 && row >= 81) && (col <= 9  && col >=1 ) ) { pattern[width* row + col] = PSTIM; } break;  
			      //
	       //100x100 coords center to lower-right tags.  First (center) segment is horizontal  works with 30-39
           case 130:  if ( (row <= 59 && row >= 51) && (col <= 59 && col >=51) ) { pattern[width* row + col] = PSTIM; } break;  //
           case 131:  if ( (row <= 59 && row >= 51) && (col <= 69 && col >=61) ) { pattern[width* row + col] = PSTIM; } break;  //
           case 132:  if ( (row <= 69 && row >= 61) && (col <= 69 && col >=61) ) { pattern[width* row + col] = PSTIM; } break;  //
           case 133:  if ( (row <= 69 && row >= 61) && (col <= 79 && col >=71) ) { pattern[width* row + col] = PSTIM; } break;  //
           case 134:  if ( (row <= 79 && row >= 71) && (col <= 79 && col >=71) ) { pattern[width* row + col] = PSTIM; } break;  //
           case 135:  if ( (row <= 79 && row >= 71) && (col <= 89 && col >=81) ) { pattern[width* row + col] = PSTIM; } break;  //
           case 136:  if ( (row <= 89 && row >= 81) && (col <= 89 && col >=81) ) { pattern[width* row + col] = PSTIM; } break;  //
           case 137:  if ( (row <= 89 && row >= 81) && (col <= 99 && col >=91) ) { pattern[width* row + col] = PSTIM; } break;  //
           case 138:  if ( (row <= 99 && row >= 91) && (col <= 99 && col >=91) ) { pattern[width* row + col] = PSTIM; } break;  //
           case 139:  if ( (row <= 89 && row >= 81) && (col <= 99 && col >=91) ) { pattern[width* row + col] = PSTIM; } break;  //
														
           default :
	       break;
	 }//case sel
       }//for col
     }//for row
     cudaMemcpy ( d_pattern, pattern, width*width*sizeof( float ), cudaMemcpyHostToDevice );
     I_loadPat( cell_layer, width, d_pattern);
}


#endif
