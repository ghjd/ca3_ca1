#ifndef INTERACTIONS_H
#define INTERACTIONS_H
#include "kernel_common.h"
#include "kernel1.h"
#include "kernel2.h"
#include "kernel3.h"
#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <GL/glew.h>
#include <GL/freeglut.h>
//locals
#include "genPats.h"

#define MAX(x, y) (((x) > (y)) ? (x) : (y))
#define PI 3.1415926

float Ax, Bx;

int DTS_PER_RENDER = 1;

int chort = 1;
int maxCnt;

int NextPath = 0;  //defines the starting pattern of the path to be recalled.  Used and updated by state 4

int trn_tii_rf = R_AE;
int A_stimulus_type = 0;  //communicate stimulus type (spot, vertical bar, horizontal bar) to kernelLauncher1 call in main
int A_stim_state = 0;     //state control of stimulus loop.
int A_rfield_type = 2;  //tell layer5 what receptive-field/feature detector to use
int A_move = 1;
int A_counter = 0;
bool en_stim, en_noise;
bool Fflag = true;  //first flag for the state machine
//stimulus types
                      //0: blank
		      //1: horizontal grating
		      //2: vertical grating
		      //3: \ left diagonal grating
		      //4: / right  diagonal grating
		      //5: horizontal bar
		      //6: vertical bar
		      //7: \ left diagonal bar
		      //8: / right diagonal bar
		      //9: spot
		      //10: 1, _, \, / one in each quadrant
//rfield types
		      //0: zero
		      //1: horizontal
		      //2: vertical
		      //3: \
		      //4: /
		      //5: all excitatory
		      //6: center/surround 

//bool dragMode = false; // mouse tracking mode
bool en_periodic = true;  // to kernel   enable periodic boundry conditions
bool en_track = false;  // to kernel   enable a track generation

double SimTime  = 0;

double A_SimTime_prev  = 0;
double A_LocTime_prev  = 0;
float  A_deltaTime = 0;
float  A_deltaLocTime = 0;

bool  flag = false;
double TestTime_prev  = 0;
float deltaTestTime = 0;


//track path stuff
float DirectionAngle = -PI/6.5;  //unmodulated direction of the track path
float DirectionMagnitude = PI/6;;  //modulation magnitude
float Fdirection = 7.0;   //frequency of direction fluctuation Hz
float Fvelocity = 6.0;   //frequency of velocity fluctuation Hz
float RawVelocity = 3500.0;  //baseline linear velocity


int2 A_loc = {150, 150};   //contains loc.x, loc.y for communicating mouse or track location to the device
int2 loc = {1, 1};   //contains loc.x, loc.y for communicating mouse or track location to the device
double loc_x , loc_y ; //current locatin in floating point for track path calculation
int    loc_x_0 = 50.0;  //putting 1 in here causes boundry problems
int    loc_y_0 = 400.0;

int iterations = 0;
int iterations_last = 0;

unsigned int pause_animation = 0;
unsigned int enable_rendering = 1;

void keyboard(unsigned char key, int x, int y) {
  if (key == 'n') {cell_switches1.en_noise = ( cell_switches1.en_noise == 0 ) ? 1 : 0; printf("Noise_Enable = %d\n",cell_switches1.en_noise);}
  if (key == 't') {
             en_track = ( en_track == 0 ) ? 1 : 0; 
             printf("Track_Enable = %d\n",en_track); 
             cell_switches1.en_stim = en_track ? true : false; 
             loc_x = loc_x_0; loc_y = loc_y_0;
             loc.x = (int)loc_x_0; loc.y = (int)loc_y_0;
  }

  if (key == 'b') {en_periodic = ( en_periodic == 0 ) ? 1 : 0; printf("Periodic Boundry = %d\n",en_periodic);}
  if (key == 'p') {pause_animation = ( pause_animation == 0 ) ? 1 : 0; printf("Pause Animation = %d\n",pause_animation);}
  if (key == 'r') {
	  resetNetwork();
  }

  if (key == 27) exit(0);
  glutPostRedisplay();
}

void mouseDrag(int x, int y) {
  loc.x = x;
  loc.y = y;
  //printf("mouseDrag X=%d\tY=%d\n", x, y);
  glutPostRedisplay();
}


void printInstructions() {
  printf("Temperature Visualizer:\n"
         "Relocate source with mouse click\n"
         "Change source temperature (-/+): s/S\n"
         "Change air temperature    (-/+): a/A\n"
         "Change ground temperature (-/+): g/G\n"
         "Change pipe radius        (-/+): r/R\n"
         "Change chamfer            (-/+): c/C\n"
         "Reset to air temperature       : z\n"
         "Exit                           : Esc\n");
}


void mouse(int button, int state, int x, int y)
{
    if (button==GLUT_LEFT_BUTTON)
    {
        switch (state) 
        {
        case GLUT_DOWN:
            cell_switches1.en_stim = true;
            break;
        case GLUT_UP:
            cell_switches1.en_stim = false;
            break;
        default:
            break;
        }
        loc.x = x;
        loc.y = y;
    }
}

void reset_syn_enables(void) {
	//syn_switchesStruct s_iB, s_iS, s_latB, s_latS, s_b2s, s_iCA3, s_s2b, s_ca3lat, s_ca32ca1;
           s_iB.en_syn = 0;
           s_iS.en_syn = 0;
           s_latB.en_syn = 0;
           s_latS.en_syn = 0;
           s_b2s.en_syn = 0;
           s_s2br.en_syn = 0;
           s_s2b.en_syn = 0;
           s_iCA3.en_syn = 0;
           s_ca3lat.en_syn = 0;
           s_ca32ca1.en_syn = 0;

	   s_iB.en_learn = 0;
           s_iS.en_learn = 0;
           s_latB.en_learn = 0;
           s_latS.en_learn = 0;
           s_b2s.en_learn = 0;
           s_s2br.en_learn = 0;
           s_s2b.en_learn = 0;
           s_iCA3.en_learn = 0;
           s_ca3lat.en_learn = 0;
           s_ca32ca1.en_learn = 0;

	   cell_switches2.en_learn = 0;
}//reset_enables

void state1_switch(int counter) { //map b onto s
	int cue = 0;
         switch ( counter ){
	       case  0: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 20, cue ); 
			genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 100, 0 );
			break;
	       case  1: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 21, cue ); 
			genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 101, 0 );
			break;
	       case  2: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 22, cue ); 
			genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 102, 0 );
			break;
	       case  3: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 23, cue );
			genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 103, 0 );
			break;
	       case  4: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 24, cue );
			genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 104, 0 );
			break;
	       case  5: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 25, cue );
			genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 105, 0 );
			break;
	       case  6: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 26, cue );
			genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 106, 0 );
			break;
	       case  7: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 27, cue );
			genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 107, 0 );
			break;
	       case  8: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 28, cue );
			genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 108, 0 );
			break;
	       case  9: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 29, cue ); //path stops here
			genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 0, 0 );  //109
			break;
               case  10: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 50, cue );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 110, 0 );
                        break;
               case  11: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 51, cue );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 111, 0 );
                        break;
               case  12: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 52, cue );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 112, 0 );
                        break;
               case  13: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 53, cue );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 113, 0 );
                        break;
               case  14: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 54, cue );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 114, 0 );
                        break;
               case  15: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 55, cue );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 115, 0 );
                        break;
               case  16: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 56, cue );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 116, 0 );
                        break;
               case  17: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 57, cue );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 117, 0 );
                        break;
               case  18: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 58, cue );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 118, 0 );
                        break;
               case  19: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 59, cue ); //path stops here, primary to the tag that points back to itself
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 0, 0 );  //119
                        break;
               case  20: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 40, cue );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 120, 0 );
                        break;
               case  21: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 41, cue );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 121, 0 );
                        break;
               case  22: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 42, cue );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 122, 0 );
                        break;
               case  23: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 43, cue );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 123, 0 );
                        break;
               case  24: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 44, cue );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 124, 0 );
                        break;
               case  25: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 45, cue );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 125, 0 );
                        break;
               case  26: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 46, cue );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 126, 0 );
                        break;
               case  27: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 47, cue );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 127, 0 );
                        break;
               case  28: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 48, cue );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 128, 0 );
                        break;
               case  29: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 49, cue ); //path stops here, primary to the tag that points back to itself
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 0, 0 ); //129  
                        break;
               case  30: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 30, cue );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 130, 0 );
                        break;
               case  31: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 31, cue );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 131, 0 );
                        break;
               case  32: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 32, cue );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 132, 0 );
                        break;
               case  33: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 33, cue );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 133, 0 );
                        break;
               case  34: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 34, cue );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 134, 0 );
                        break;
               case  35: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 35, cue );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 135, 0 );
                        break;
               case  36: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 36, cue );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 136, 0 );
                        break;
               case  37: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 37, cue );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 137, 0 );
                        break;
               case  38: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 38, cue );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 138, 0 );
                        break;
               case  39: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 39, cue ); //path stops here, primary to the tag that points back to itself
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 0, 0 );  //139
                        break;
               default: 
			break;
	}
}

void state2_switch(int counter ) {
           switch ( counter ){
               case  0: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 21, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 100, 0 );
                        break;
               case  1: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 22, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 101, 0 );
                        break;
               case  2: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 23, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 102, 0 );
                        break;
               case  3: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 24, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 103, 0 );
                        break;
               case  4: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 25, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 104, 0 );
                        break;
               case  5: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 26, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 105, 0 );
                        break;
               case  6: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 27, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 106, 0 );
                        break;
               case  7: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 28, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 107, 0 );
                        break;
               case  8: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 29, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 108, 0 );
                        break;
               case  9: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 51, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 110, 0 );
                        break;
               case  10: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 52, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 111, 0 );
                        break;
               case  11: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 53, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 112, 0 );
                        break;
               case  12: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 54, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 113, 0 );
                        break;
               case  13: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 55, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 114, 0 );
                        break;
               case  14: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 56, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 115, 0 );
                        break;
               case  15: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 57, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 116, 0 );
                        break;
               case  16: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 58, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 117, 0 );
                        break;
               case  17: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 59, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 118, 0 );
                        break;
               case  18: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 41, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 120, 0 );
                        break;
               case  19: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 42, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 121, 0 );
                        break;
               case  20: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 43, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 122, 0 );
                        break;
               case  21: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 44, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 123, 0 );
                        break;
               case  22: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 45, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 124, 0 );
                        break;
               case  23: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 46, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 125, 0 );
                        break;
               case  24: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 47, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 126, 0 );
                        break;
               case  25: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 48, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 127, 0 );
                        break;
               case  26: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 49, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 128, 0 );
                        break;
               case  27: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 31, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 130, 0 );
                        break;
               case  28: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 32, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 131, 0 );
                        break;
               case  29: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 33, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 132, 0 );
                        break;
               case  30: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 34, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 133, 0 );
                        break;
               case  31: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 35, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 134, 0 );
                        break;
               case  32: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 36, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 135, 0 );
                        break;
               case  33: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 37, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 136, 0 );
                        break;
               case  34: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 38, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 137, 0 );
                        break;
               case  35: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 39, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 138, 0 );
                        break;
               case  36: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 0, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 0, 0 );
                        break;
               default:
                        break;
           }
}
void state3_switch(int counter ) { //learn the reverse path.  A small-pat is associated with the previous big-pat in the sequence
           switch ( counter ){
               case  0: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 20, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 101, 0 );
                        break;
               case  1: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 21, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 102, 0 );
                        break;
               case  2: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 22, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 103, 0 );
                        break;
               case  3: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 23, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 104, 0 );
                        break;
               case  4: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 24, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 105, 0 );
                        break;
               case  5: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 25, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 106, 0 );
                        break;
               case  6: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 26, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 107, 0 );
                        break;
               case  7: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 27, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 108, 0 );
                        break;
               case  8: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 28, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 109, 0 );
                        break;
               case  9: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 50, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 111, 0 );
                        break;
               case  10: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 51, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 112, 0 );
                        break;
               case  11: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 52, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 113, 0 );
                        break;
               case  12: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 53, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 114, 0 );
                        break;
               case  13: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 54, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 115, 0 );
                        break;
               case  14: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 55, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 116, 0 );
                        break;
               case  15: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 56, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 117, 0 );
                        break;
               case  16: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 57, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 118, 0 );
                        break;
               case  17: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 58, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 119, 0 );
                        break;
               case  18: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 40, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 121, 0 );
                        break;
               case  19: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 41, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 122, 0 );
                        break;
               case  20: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 42, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 123, 0 );
                        break;
               case  21: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 43, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 124, 0 );
                        break;
               case  22: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 44, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 125, 0 );
                        break;
               case  23: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 45, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 126, 0 );
                        break;
               case  24: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 46, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 127, 0 );
                        break;
               case  25: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 47, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 128, 0 );
                        break;
               case  26: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 48, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 129, 0 );
                        break;
               case  27: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 30, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 131, 0 );
                        break;
               case  28: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 31, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 132, 0 );
                        break;
               case  29: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 32, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 133, 0 );
                        break;
               case  30: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 33, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 134, 0 );
                        break;
               case  31: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 34, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 135, 0 );
                        break;
               case  32: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 35, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 136, 0 );
                        break;
               case  33: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 36, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 137, 0 );
                        break;
               case  34: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 37, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 138, 0 );
                        break;
               case  35: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 38, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 139, 0 );
                        break;
               case  36: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 0, 0 );
                        genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 0, 0 );
                        break;
               default:
                        break;
           }
}


void idle(void) {
  unsigned int i, count;
  int step = 2;
  float stateTime = 0.5;
  float stepTime = 0.015;
  float stopTime = 0.005;
  float endTime = stateTime + 2*stopTime;
  float Loops = 2;  //number of times around the circuit
  //start in pause state after one iteration to initialize the image
  if ( iterations == 0 ) { 
	  pause_animation = 1; 
	  //A_loc = {100, 100};
	  printf("pausing at [%d][%d]...\n",A_loc.x, A_loc.y);
          ++iterations;  
  }
  if ( pause_animation == 0 ) {
    ++iterations;  //increments every render, (DTS_PER_RENDER * dT) seconds

    SimTime += DTS_PER_RENDER * dT;  //this routine gets called every DTS_PER_RENDER dTs

    A_deltaTime = SimTime - A_SimTime_prev;
    A_deltaLocTime = SimTime - A_LocTime_prev;

    int cue = false;
    //train CA3 to CA1 cuing path.  Train ca3 lateral synapses to pattern complete, ca3_2_ca1 synapses to map 20 onto 20.
    //A_synapse_i_pc, C_synapse_i_pc enabled.  All other synapses disabled.
    //load patterns to be associated into C_cellLayer1, A_cellLayer1.  
    //enable C_synapse_pc_lateral, ca3_2_ca1_synapse learning
    if ( A_stim_state == 0 ) {  //train the s2b synapses after loading s pattern and the next b pattern
       if ( Fflag ) {  ////run these lines only on first cycle in this state
           DTS_PER_RENDER = 100;
           A_stimulus_type = 21;
	   reset_syn_enables();
	   cell_switches2.en_cancel_xtalk = 1; //turn on while training this group
           switch ( A_counter ){
               case  0: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 20, 0 );  //20 into CA1 
                        genPats( big_in_pat, d_big_in_pat, C_cellLayer1,  W1, 201, 0 );
                        break;
               case  1: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 50, 0 ); // 50
                        genPats( big_in_pat, d_big_in_pat, C_cellLayer1,  W1, 202, 0 ); 
                        break;
               case  2: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 40, 0 );  //49
                        genPats( big_in_pat, d_big_in_pat, C_cellLayer1,  W1, 203, 0 );  
                        break;
               case  3: genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 30, 0 );  //30
                        genPats( big_in_pat, d_big_in_pat, C_cellLayer1,  W1, 200, 0 );  
                        break;
               default:
                        break;
           }
       }
       Fflag = false;
       if (  A_deltaTime >  0.001 ) { s_ca32ca1.en_learn = 1; s_ca3lat.en_learn = 1; s_iCA3.en_syn = 1; s_iB.en_syn = 1; cell_switches2.en_learn = 1; }     //set stuff here
       if (  A_deltaTime >  0.045 ) { A_stimulus_type = 0; s_ca32ca1.en_learn = 0; s_ca3lat.en_learn = 0;}
       if (  A_deltaTime >  0.05  ) { reset_syn_enables(); }  //reset
       if (  A_deltaTime >  0.055 ) {  //move on to either then next pattern or next state
         Fflag = true;
         if ( A_counter == 3 ) {  // 3
           A_stim_state = 100;
	   //reset_syn_enables();
	   cell_switches2.en_cancel_xtalk = 0;//turn off at end of training this group
           printf("Entering State %d\n", A_stim_state);
           A_SimTime_prev = SimTime; A_deltaTime = 0; A_counter = 0;
	   genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 0, 0 ); //nothing in the Barray
	   genPats( big_in_pat, d_big_in_pat, C_cellLayer1,  W1, 0, 0 ); //nothing in the CA3 array
	   genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 0, 0 ); //nothing in sthe Sarray
           s_ca32ca1.en_learn = s_ca3lat.en_learn = s_iCA3.en_syn = s_iB.en_syn = cell_switches2.en_learn = 0;      
         } else { A_SimTime_prev = SimTime; A_deltaTime = 0; A_counter++; }
       }
    }//stim state 0
    
    //clear residual activity becore cuing
    if ( A_stim_state == 100 ) {  
       cell_switches2.en_cancel_xtalk = 0; 
       if (  A_deltaTime > 0.01 ) {
             A_stim_state = 1;
	     Fflag = 1;
             printf("Entering State %d\n", A_stim_state);
             A_SimTime_prev = SimTime; A_deltaTime = 0; A_counter = 0;
       }
    }//state 100

    if ( A_stim_state == 1  && iterations > 1) {  //train the lateral synapses to store the patterns.  train the b2s synapses to activate s in response to b
       if ( Fflag ) {
	   enable_rendering = 1;
           A_stimulus_type = 21;
	   reset_syn_enables();
	   cell_switches2.en_cancel_xtalk = 1; //turn on while training this group
           state1_switch( A_counter) ;
       }
       Fflag = false;
       if (  A_deltaTime >  0.001 ) { s_iB.en_syn = s_iS.en_syn = cell_switches2.en_learn = 1; s_latB.en_learn = s_latS.en_learn = s_b2s.en_learn = 1;} //enable learning in all but s2b (trained later)
       if (  A_deltaTime >  0.045 ) { reset_syn_enables(); A_stimulus_type = 0; }
       if (  A_deltaTime >  0.055 ) { 
	 Fflag = true;
	 if ( chort ) {
		 if ( A_counter == 38 ) { A_counter = 39;}
		 if ( A_counter == 28 ) { A_counter = 29;}
		 if ( A_counter == 18 ) { A_counter = 19;}
		 if ( A_counter == 8 ) { A_counter = 9;}
         }
	 if ( A_counter == 39 ) { //39
           A_stim_state = 2;   
           printf("[INFO][%d][%d]Training first-pass complete!\n", A_stim_state, A_counter);
	   printf("Entering State %d\n", A_stim_state);
	   A_SimTime_prev = SimTime; A_deltaTime = 0; A_counter = 0;
	   cell_switches2.en_cancel_xtalk = 0; //turn off after training this group
	 } else { A_SimTime_prev = SimTime; A_deltaTime = 0; A_counter++; } 
       }
    }


    if ( A_stim_state == 2 ) {  //train the s2b synapses after loading s pattern and the next b pattern
       if ( Fflag ) {  ////run these lines only on first cycle in this state
           A_stimulus_type = 21;
           reset_syn_enables();
	   cell_switches2.en_cancel_xtalk = 1; //turn on while training this group
           state2_switch( A_counter) ;
       }
       Fflag = false;
       if (  A_deltaTime >  0.001 ) { s_iB.en_syn = s_iS.en_syn = s_s2b.en_learn = 1;} 
       if (  A_deltaTime >  0.045 ) { A_stimulus_type = 0; }
       if (  A_deltaTime >  0.05) { reset_syn_enables();}
       if (  A_deltaTime >  0.055 ) {  //move on to either then next pattern or next state
         Fflag = true;
         s_iB.en_syn = true;
         s_iS.en_syn = true;
	 if ( chort ) {
		 if ( A_counter == 34 ) { A_counter = 35;}
		 if ( A_counter == 25 ) { A_counter = 26;}
		 if ( A_counter == 16 ) { A_counter = 17;}
		 if ( A_counter == 7 ) { A_counter = 8;}
         }
	 if ( A_counter == 35 ) { //35
           A_stim_state = 200;
           reset_syn_enables();
           printf("[INFO][%d][%d]Training second-pass complete!\n", A_stim_state, A_counter);
           printf("Entering State %d\n", A_stim_state);
           enable_rendering = 1;
           //pause_animation = 1; 
           A_SimTime_prev = SimTime; A_deltaTime = 0; A_counter = 0;
	   genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 0, 0 ); //nothing in the Barray
	   genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 0, 0 ); //nothing in sthe Sarray
         } else { A_SimTime_prev = SimTime; A_deltaTime = 0; A_counter++; }
       }
    }
    
    //clear residual activity becore cuing
    if ( A_stim_state == 200 ) {  
       cell_switches2.en_cancel_xtalk = 0; 
       if (  A_deltaTime > 0.01 ) {
             A_stim_state = 3;
	     Fflag = 1;
             printf("Entering State %d\n", A_stim_state);
             A_SimTime_prev = SimTime; A_deltaTime = 0; A_counter = 0;
       }
    }//state 4

    if ( A_stim_state == 3 ) {  //train the s2br synapses after loading s pattern and the previous b pattern
       if ( Fflag ) {  ////run these lines only on first cycle in this state
           A_stimulus_type = 21;
           reset_syn_enables();
           cell_switches2.en_cancel_xtalk = 1; //turn on while training this group
           state3_switch( A_counter) ;
       }
       Fflag = false;
       if (  A_deltaTime >  0.001 ) { s_iB.en_syn = s_iS.en_syn = s_s2br.en_learn = 1;} 
       if (  A_deltaTime >  0.045 ) { A_stimulus_type = 0; }
       if (  A_deltaTime >  0.05) { reset_syn_enables();}
       if (  A_deltaTime >  0.055 ) {  //move on to either then next pattern or next state
         Fflag = true;
         s_iB.en_syn = true;
         s_iS.en_syn = true;
	 if ( chort ) {
		 if ( A_counter == 34 ) { A_counter = 35;}
		 if ( A_counter == 25 ) { A_counter = 26;}
		 if ( A_counter == 16 ) { A_counter = 17;}
		 if ( A_counter == 7 ) { A_counter = 8;}
         }
	 if ( A_counter == 35 ) { //35
           A_stim_state = 4;
           reset_syn_enables();
           printf("[INFO][%d][%d]Training third-pass complete!\n", A_stim_state, A_counter);
           printf("Entering State %d\n", A_stim_state);
           printf("pausing at state [%d]. Type p to restart\n", A_stim_state);
           enable_rendering = 1;
           //pause_animation = 1; 
           A_SimTime_prev = SimTime; A_deltaTime = 0; A_counter = 0;
           genPats( big_in_pat, d_big_in_pat, A_cellLayer1,  W1, 0, 0 ); //nothing in the Barray
           genPats( small_in_pat, d_small_in_pat, B_cellLayer1,  W4, 0, 0 ); //nothing in sthe Sarray
         } else { A_SimTime_prev = SimTime; A_deltaTime = 0; A_counter++; }
       }
    } 
  
    //clear residual activity becore cuing
    if ( A_stim_state == 4 ) {  
       cell_switches2.en_cancel_xtalk = 1; //enable suppression of xtalk cells
       if (  A_deltaTime > 0.01 ) {
             A_stim_state = 5;
	     Fflag = 1;
             printf("Entering State %d\n", A_stim_state);
             A_SimTime_prev = SimTime; A_deltaTime = 0; A_counter = 0;
       }
    }//state 4

    //Cue the first pattern in the sequence, let Barray & then Sarray settle, reset Barray
    //Barray input to pattern-array synapses (s_sw1) and lateral pattern-array  (s_sw1) synapses are enabled
    if ( A_stim_state == 5 ) {  
       if ( Fflag ) {
             DTS_PER_RENDER = 1; //2
             if ( NextPath == 100 ) { printf("********Done!*******\n"); exit(0);}
             reset_syn_enables();
             s_latB.en_syn = s_latS.en_syn = 1; //Configure for CA3 B to project to S
	     s_iCA3.en_syn = 1; s_ca32ca1.en_syn = 1; s_ca3lat.en_syn = 1; 
             A_stimulus_type = 21;  //get pattern from genPats
	     if ( NextPath == 0 ) { NextPath = 201; }
             genPats( big_in_pat, d_big_in_pat, C_cellLayer1,  W1, NextPath, 1 );  //NextPath specifies first pattern in the sequence to Barray
             if ( NextPath == 203 ) { NextPath = 100;}
             if ( NextPath == 200 ) { NextPath = 203;}
             if ( NextPath == 202 ) { NextPath = 200;}
             if ( NextPath == 201 ) { NextPath = 202;}
       }
       Fflag = 0;
       if (  A_deltaTime >  0.015 ) { A_stimulus_type = 0; } //blank input pattern
       if (  A_deltaTime >  0.02 ) { 
	     reset_syn_enables(); s_latB.en_syn = s_latS.en_syn = s_b2s.en_syn = 1; s_ca32ca1.en_syn = 1; s_ca3lat.en_syn = 1; 
       }//disable everything except array laterals
       if (  A_deltaTime > 0.025 ) { 
             A_stim_state = 6;
	     Fflag = 1;
             printf("Entering State %d\n", A_stim_state);
             A_SimTime_prev = SimTime; A_deltaTime = 0; A_counter = 0;
             DTS_PER_RENDER = 10; //2
       }
    }//state 6


    if ( A_stim_state == 6 ) {  
       A_stimulus_type = 0;
       // Big-array develops based on external (from input layer) or internal (from small array) cue. 
       //           i-synapses enabled,  b2s-synapses disabled, s2b-synapses disabled if external cue
       //           i-synapses disabled, b2s-synapses disabled, s2b-synapses enabled if  internal que
       // When Big-array stabilizes,
       //      s2b-synapses disabled
       //      s-array reset
       //      b2s-synapses enabled
       // When Small-array stabilizes,
       //      b2s-synapses disabled
       //      b-array reset
       //      s2b-synapses enabled
       if (Fflag){
	   reset_syn_enables();
	   s_latB.en_syn = s_latS.en_syn = s_b2s.en_syn = s_ca3lat.en_syn = 1;
       }
       Fflag = 0;
       if (  A_deltaTime >  0.001 ) { s_latB.en_syn = 0; s_latS.en_syn = 1; s_b2s.en_syn = 0; s_s2b.en_syn = s_s2br.en_syn = 0; } // 0100 disable big array, enable small array
       if (  A_deltaTime >  0.008)  { s_latB.en_syn = 1; s_latS.en_syn = 1; s_b2s.en_syn = 0; if ( A_counter < (chort ? 8 : 9)) {s_s2b.en_syn = 1;} else {s_s2br.en_syn = 1;} } 
       if (  A_deltaTime >  0.016 ) { s_latB.en_syn = 1; s_latS.en_syn = 0; s_b2s.en_syn = 0; s_s2b.en_syn = s_s2br.en_syn = 0; } // 1000 enable big array, disable small array
       if (  A_deltaTime >  0.025 ) { s_latB.en_syn = 1; s_latS.en_syn = 1; s_b2s.en_syn = 1; } // 1110 enable big array, enable small array, enable b2s
       if (  A_deltaTime >  0.032  ) {
	 A_counter++;
         A_SimTime_prev = SimTime; A_deltaTime = 0;
         if ( A_counter == 4 ) { s_ca3lat.en_syn = 0; printf("***State 6 Counter==4 Clearing stimulus pattern s_ca3lat.en_syn=0\n");}
	 maxCnt = chort ? 16 : 18;
         if ( A_counter > maxCnt ) { // 9 time has progressed though ten steps. Time to cue the next pattern
	   A_counter = 0;
           A_stim_state = 4; //go back and cue the next path
	   Fflag = 1;
	   reset_syn_enables();
	 }
	 printf("***State 5 Counter going to %d\n",A_counter);
       } 
    }//state 5


/***************************************************************************************************/


    //automatically terminate simulation when doing automated tuning
    //if ( SimTime > 5.0  ) { exit(0); }  //exit after one simulated second
    if ( (iterations % 100)==0 || iterations == 10 ) {   //every (DTS_PER_RENDER * dT * 100 )
       printf("*** Time=%.4f Seconds iterations[%d] ***\n", SimTime, iterations );
    }
  }
}

#endif

