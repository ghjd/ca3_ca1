#ifndef KERNEL1_H
#define KERNEL1_H

#include "kernel_common.h"

//common convolutional filter used by synapse groups synapse2 and up
__constant__ float  d_weights_cs[(2*RADIUS+1)*(2*RADIUS+1)];  //center-surround weights
__constant__ float  d_weights_cs_b[(2*RADIUS+1)*(2*RADIUS+1)]; //center-surround weights with smaller center
__constant__ float  d_weights_ae[(2*RADIUS+1)*(2*RADIUS+1)];  //all-excitatory weights

//these get used by synapse1 group between L1 and L2
__constant__ float  d_weights_cs_I[(2*RADIUS+1)*(2*RADIUS+1)];  //center-surround weights
__constant__ float  d_weights_ae_I[(2*RADIUS+1)*(2*RADIUS+1)];  //all-excitatory weights

//these get used by synapse2 group between LGN and V1L4 to be orientationally sensitive
__constant__ float  d_weights_V[(2*RADIUS+1)*(2*RADIUS+1)];  //  | excitatory center vertical strip, inhibitory left/right wings
__constant__ float  d_weights_H[(2*RADIUS+1)*(2*RADIUS+1)];  //  _ excitatory center horizontal strip, inhibitory left/right wings
__constant__ float  d_weights_B[(2*RADIUS+1)*(2*RADIUS+1)];  //  \ backslash receptive field. Like d_weights_V rotated 90 degress left
__constant__ float  d_weights_F[(2*RADIUS+1)*(2*RADIUS+1)];  //  / forward slash receptive field. Like d_weights_V rotated 90 degress right

//these get used by synapse groups V1L4->V2S and V2S->V2P small radius projections
#define RADIUSV2 2
__constant__ float  d_weights_cs_v2[(2*RADIUS+1)*(2*RADIUS+1)];  //center-surround weights
__constant__ float  d_weights_ae_v2[(2*RADIUS+1)*(2*RADIUS+1)];  //all-excitatory weights

//activates stimKernel, the input layer roughly modeling retina ganglion cells
void I_cellKernelLauncher(uchar4 *d_out, uchar4 *isyn,  lif_data_type *lif_data, int w, int2 loc, cell_switchesStruct cell_switches, cellParamStruct cellParams, int layerNumber, int type, int report_control);
void resetCells(lif_data_type *lif_data, int w, cellParamStruct cellParams, int layerNumber);

//all the multiplicity of the following routines should eventually be refactored into common routines with more parametric flexibility.  They tend to do almost the same thing with just a few lines of difference.
void generateReceptiveFields ();
void resetSnaps (L1_synapse_data_type *synapse_ptr, int w, int h, synParamStruct synParams, int type );
void resetSnapsP (P_synapse_data_type *synapse_ptr, int w, int h, synParamStruct synParams, int type );
void L1_synapseKernelLauncher(lif_data_type *lif_data_a, lif_data_type *lif_data_b, L1_synapse_data_type *synapse, int w,  syn_switchesStruct syn_switches, int radius, bool accumulate, int rfield_type );
void P_synapseKernelLauncher(lif_data_type *lif_data_a, lif_data_type *lif_data_b, P_synapse_data_type *synapse, int w, syn_switchesStruct syn_switches, int radius, bool accumulate );
void I_synapseKernelLauncher (lif_data_type *lif_data_a, lif_data_type *lif_data_b, L1_synapse_data_type *synapse, int w, syn_switchesStruct syn_switches, int radius, bool accumulate, bool cs_or_ae );
void P_b2s_synapseKernelLauncher(lif_data_type *lif_data_a, lif_data_type *lif_data_b, P_synapse_data_type *synapse, int w, syn_switchesStruct syn_switches, int radius, bool accumulate ); 
void L3_2_L2_synapseKernelLauncher(lif_data_type *lif_data_a, lif_data_type *lif_data_b, L1_synapse_data_type *synapse, int w_pre, int w_post, syn_switchesStruct syn_switches, int radius  );
void P_forgetLauncher( P_synapse_data_type *synapse );
void b2s_synapseKernelLauncher(lif_data_type *lif_data_a, lif_data_type *lif_data_b, P_synapse_data_type *synapse, int w, syn_switchesStruct syn_switches, int radius  ); //pass in big array width.  Small array hard-coded to 1/3 width
void s2b_synapseKernelLauncher(lif_data_type *lif_data_a, lif_data_type *lif_data_b, P_synapse_data_type *synapse, int w_pre, int w_post, syn_switchesStruct syn_switches, int radius  );

void I_loadPat (lif_data_type *layer, int w, float *pattern );


#endif
