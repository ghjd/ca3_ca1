#ifndef KERNEL2_H
#define KERNEL2_H

#include "kernel_common.h"

void cellKernelLauncher2(uchar4 *d_out,  uchar4 *isyn, lif_data_type *lif_data, int w, int2 loc, cell_switchesStruct cell_switches, cellParamStruct cellParams, int layerNumber );
void resetCells2(lif_data_type *lif_data, int w, cellParamStruct cellParams, int layerNumber);

#endif
