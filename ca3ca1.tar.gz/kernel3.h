#ifndef KERNEL3_H
#define KERNEL3_H

#include "kernel_common.h"

//calcium t current related params 1.7e-7
#define G_T 4.0e-7

//H is the non-inactivated fraction of Ca_t channels.  Slow to rise (VM < V_H), fast to fall (Vm > V_H).
// dhdt = ( Vm > V_H ) ? -1.0 * lif_data[idx].d_h_t / H_TAU_F : ( (1.0 - lif_data[idx].d_h_t) / H_TAU_R); //Smith 2000 eqn 3
#define H_TAU_R 0.10
//H_TAU_F defines the duration of the burst
#define H_TAU_F 0.04
//this is the t-current inactivation threshold voltage.  Set it slightly above voltage to which inhibition drives Vm, but not so much that E_K spike resets have much effect on H
#define V_H     -0.07

//T-current floor.  It only flows if Vm > V_T.  Set it just below resting potential
#define V_T     -0.07


void cellKernelLauncher3(uchar4 *d_out,  uchar4 *isyn, lif_data_type *lif_data, int w, int2 loc, cell_switchesStruct cell_switches, cellParamStruct cellParams, int layerNumber );
void resetCells3(lif_data_type *lif_data, int w, cellParamStruct cellParams, int layerNumber);

#endif
