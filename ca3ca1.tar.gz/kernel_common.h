#ifndef KERNEL_COMMON_H
#define KERNEL_COMMON_H

#include <stdio.h>
#include <cuda.h>
#include <curand_kernel.h>
#include "cuda_fp16.h"
//#include "helper_cuda.h"

//int divUp(int a, int b) { return (a + b - 1) / b; }  //ld errors on multiple definitions of divUp

//vokoscreen 3.1 seems to be broken, at least on this system.
//use Screencast to capture a webm file into ~/Videos/Screencasts/
//use ffmpeg -i test.webm -vcodec libx264 -vf pad="width=ceil(iw/2)*2:height=ceil(ih/2)*2" test.mp4
//to translate into mp4

#define NUM_PATS 10

#define ISTIM 0.6e-9

//defines the height of stimulus bar when in bar mode
#define BAR_HEIGHT  115
//the width comes out twice this
#define BAR_WIDTH 2

//this is the commonly used receptive field radius
#define RADIUS 15
//
//this is the radius of lateral connections used by P_plastic synapses  26
#define RADIUSP  40

//this is the receptive field radius between input layer 1 and 2.  Must be smaller than RADIUS
#define RADIUSI 2

#define TX 32
#define TY 32

#define W1 300
#define W2 300
#define W3 100
#define W4 100

//higher order thalamic nuclei
#define W20 100

//receptive field types
#define R_Z    0
#define R_H    1
#define R_V    2
#define R_BS   3
#define R_FS   4
#define R_AE   5
#define R_CS   6
#define R_CS_B 7


//constants
#define dT 1.0e-4
#define E_L -60.0e-3
#define E_K -86.1e-3
#define G_L 8.0e-9

#define delayTap   0x0000000000000001  //how many dT's of delay		1,2,4,8, 10, ...
#define delayBank  0            //0: 1:64 dTs of delay  1: 65:128 dTs of delay  2: 129:196 dT of delay

//host struct for loading synapse parameters
//gets passed down as parameters to device
#define NUM_SYN_PARAMS 2
typedef struct synParams{
    float imax_syn;
    float tau_syn;
} synParamStruct ;

//device-side cell struct
typedef struct lif_data {
  //unique cell parameters
  float Cm;             //Cell membrane capacitance.  Defined in cellParams, then randomized a bit
  //dynamic variables
  float d_vm;           //membrane voltage
  float d_Isra;         //spike-rate adaptation current
  float d_Gref;         //refractory conductance
  float d_Isyn;         //synaptic current into soma
  //calcium params for bursting
  float d_h_t;          //calcium T-current state variable
  float d_vms;          //10mS smoothing filter d_vm to become d_vms, averaged version without the quick spike transients
  float d_Isyns;        //5mS smoothing filter d_Isyn to become d_Isyns, averaged version without the quick spike transients
  curandState d_curandState;  //curand state value
  unsigned int d_curandVal;    //curand prng random value
  unsigned long int d_delay_2;       // 64-bit word  for 12.8mS delay
  unsigned long int d_delay_1;       // 64-bit word  for 12.8mS delay
  unsigned long int d_delay_0;       // 64-bit word  for 6.4mS delay
  int int_misc;                      //general purpose integer
  float float_misc;                  //general purpose float
  float now;                         //the current time (iterations * dT)
  bool hasBeenSet = false;     //marks whether a cell has ever been part of a training pattern
  bool setThisCycle = false;   //marks whether a cell is part of the current training pattern
  bool disable = false;        //turn off this cell to supress xtalk
  float state = 0.0;	       //used by I_ layer to specify state of this cell in the input pattern
} lif_data_type ;


//host struct for loading cell parameters
#define NUM_CELL_PARAMS 10 
typedef struct cellParams{
    unsigned long int SEED;
    float Cm;
    float Vth;
    float delta_Vth;
    float tau_sra;
    float sra_a;
    float sra_b;
    float tau_gref;
    float delta_gref;
    float sigma_i_noise;
} cellParamStruct ;

typedef struct cell_switches{
        bool en_motion_sensitivity = true; 
        bool en_stim = true; 
        bool en_noise = false;   //to kernel enable Vm noise for spontaneous activity
        bool en_theta = false;  // to kernel   enable theta-rythm process in lgn, trn
        bool en_cue = false;    // create a cue from a stimulus pattern: trunkate the pattern int a fragment of itself
        bool en_cancel_xtalk = true;    // keep track whether this cell is in more than one training patter.  Suppress activity if so in kernel2
        bool en_learn = false;   //tell the cell whether synaptic plasticity is enabled.  Used by xtalk suppression
} cell_switchesStruct ;

typedef struct syn_switches{
        bool en_periodic = true; 
        bool en_noise = false;   //to kernel enable Vm noise for spontaneous activity
        bool en_p2p = false;     //point to point connectivity rather than receptive-field radius connectivity
        bool en_learn = false;   //enable synaptic plasticity in P_ synapses
        bool en_syn = true;      //global enable/disable for this synapse group
} syn_switchesStruct ;

//device-side synapse struct
//defines the behavior of a particular synapse group and its associated run-time state
typedef struct L1_syn_data {
  //parameters
  float imax_syn;
  float tau_syn;
  //run-time data for all synapses of this type
  float syn_currents[2*RADIUS+1] [2*RADIUS+1]; //indexing from 0 to 2*field_radius.  left: [0:field_radius-1]  center self connection[field_radius]   right [field_radius+1:2*field_radius]
} L1_synapse_data_type;

//device-side synapse struct for synapse with plasticity for learning
//defines the behavior of a particular synapse group and its associated run-time state
typedef struct P_syn_data {
  //parameters
  float imax_syn;
  float tau_syn;
  //run-time data for all synapses of this type
  //indexing from 0 to 2*field_radius.  left: [0:field_radius-1]  center self connection[field_radius]   right [field_radius+1:2*field_radius]
  float syn_weights[2*RADIUSP+1] [2*RADIUSP+1]; 
  float syn_currents[2*RADIUSP+1] [2*RADIUSP+1]; 
} P_synapse_data_type;

//support routines used by the kernels.  Defined in kernel1
int divUp(int a, int b);

//it doesn't seem possible to put __device__ routines here

#endif //KERNEL_COMMON
