#ifndef LOAD_PARAMS_H
#define LOAD_PARAMS_H
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

//the expected order of synapse parameters in the control file
//must match kernel.h cellParamList struct definition
char synParamList[NUM_CELL_PARAMS][100] = {
    "imax_syn",
    "tau_syn"
};

int loadSynParams( char* fileName, synParams* structPtr ) {
    FILE* ptr = fopen( fileName, "r");
    if (ptr == NULL) {
        printf("[ERROR]loadSynParams unable to load %s: file not found.",fileName);
        return 0;
    }

    char paramName[100];
    float  value;

    int index = 0;
    char param[100];
    //struct cellParams *structPtr;
        while ( index < NUM_SYN_PARAMS ) {  //loop through each of the params
        //printf("\n[INFO][%d]filename %s parameter %s \n", index, fileName, synParamList[index] );
        if (fscanf(ptr, "%s\t%f", param, &value) == 2){
                //printf("[INFO][%d]filename %s parameter %s line %s\n",index, fileName, cellParamList[index], param );
                if ( strcmp( param, synParamList[index] ) != 0 ) {
                     printf("[ERROR]%s appears to be out of order for parameter %s, expecting %s\n",fileName, param, synParamList[index] );
                     return 1;
                }
                switch( index ) {
                        case 0: { structPtr->imax_syn = value; break;}
                        case 1: { structPtr->tau_syn = value;  break;}
                        default: ;
                }
        } else {
            printf("[ERROR]%s appears to have a problem with parameter %s\n",fileName, synParamList[index] );
            return 1;
        }
        index++;
    }
    return 0;
}

//the expected order of parameters in the control file
//must match kernel.h cellParamList struct definition
char cellParamList[NUM_CELL_PARAMS][100] = {
    "SEED",
     "Cm",
     "Vth",
     "delta_Vth",
     "tau_sra",
     "sra_a",
     "sra_b",
     "tau_gref",
     "delta_gref",
     "sigma_i_noise"
};

//read cell parameters from text file fileName
//load parameters into host-side data structure of type cellParams
int readCellParamsFromFile( char* fileName, cellParams* structPtr ) {
    FILE* ptr = fopen(fileName, "r");
    if (ptr == NULL) {
        printf("no such file.");
        return 0;
    }

    char paramName[100];
    float  value;

    int index = 0;
    char param[100];
    //struct cellParams *structPtr;
        while ( index < NUM_CELL_PARAMS ) {  //loop through each of the params
        //printf("\n[INFO][%d]filename %s parameter %s \n", index, fileName, cellParamList[index] );
        if (fscanf(ptr, "%s\t%f", param, &value) == 2){
                //printf("[INFO][%d]filename %s parameter %s line %s\n",index, fileName, cellParamList[index], param );
                if ( strcmp( param, cellParamList[index] ) != 0 ) {
                     printf("[ERROR]%s appears to be out of order for parameter %s, expecting %s\n",fileName, param, cellParamList[index] );
                     return 1;
                }
                switch( index ) {
                        //SEED is unsigned long int.  Everything else is float
                        case 0: { structPtr->SEED = (unsigned long int) value; break;}
                        case 1: { structPtr->Cm =  value; break;}
                        case 2: { structPtr->Vth =  value;  break;}
                        case 3: { structPtr->delta_Vth =  value; break;}
                        case 4: { structPtr->tau_sra =  value; break;}
                        case 5: { structPtr->sra_a =  value; break;}
                        case 6: { structPtr->sra_b =  value; break;}
                        case 7: { structPtr->tau_gref =  value; break;}
                        case 8: { structPtr->delta_gref =  value; break;}
                        case 9: { structPtr->sigma_i_noise =  value; break;}
				/*
                        case 0: { structPtr->SEED = (unsigned long int) value; printf("[INFO]layer1.SEED=%lu\n", structPtr->SEED); break;}
                        case 1: { structPtr->Cm =  value; printf("[INFO]layer1.Cm=%e\n",  structPtr->Cm); break;}
                        case 2: { structPtr->Vth =  value; printf("[INFO]layer1.Vth=%e\n",  structPtr->Vth); break;}
                        case 3: { structPtr->delta_Vth =  value; printf("[INFO]layer1.delta_Vth=%e\n",  structPtr->delta_Vth); break;}
                        case 4: { structPtr->tau_sra =  value; printf("[INFO]layer1.tau_sra=%e\n",  structPtr->tau_sra); break;}
                        case 5: { structPtr->sra_a =  value; printf("[INFO]layer1.sra_a=%e\n",  structPtr->sra_a); break;}
                        case 6: { structPtr->sra_b =  value; printf("[INFO]layer1.sra_b=%e\n",  structPtr->sra_b); break;}
                        case 7: { structPtr->tau_gref =  value; printf("[INFO]layer1.tau_gref=%e\n",  structPtr->tau_gref); break;}
                        case 8: { structPtr->delta_gref =  value; printf("[INFO]layer1.delta_gref=%e\n",  structPtr->delta_gref); break;}
                        case 9: { structPtr->sigma_i_noise =  value; printf("[INFO]layer1.sigma_i_noise=%e\n",  structPtr->sigma_i_noise); break;}
			*/
                        default: ;
                }
        } else {
            printf("[ERROR]%s appears to have a problem with parameter %s\n",fileName, cellParamList[index] );
            return 1;
        }
        index++;
    }
    return 0;
}


#endif
