#include "kernel1.h"
#include "kernel2.h"
#include "kernel3.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> //for sleep function
#include <GL/glew.h>
#include <GL/freeglut.h>
#include <cuda_runtime.h>
#include <cuda_gl_interop.h>
#include <curand_kernel.h>

#include "interactions.h"
#include "common.h"
#include "genPats.h"

extern double SimTime;


void render() {

  //the cell Vm arrays
  cudaGraphicsMapResources(1, &A_layers[1].cuda_pbo_resource[0], 0); cudaGraphicsResourceGetMappedPointer((void **)&A_layers[1].vm, NULL, A_layers[1].cuda_pbo_resource[0]);
  cudaGraphicsMapResources(1, &A_layers[2].cuda_pbo_resource[0], 0); cudaGraphicsResourceGetMappedPointer((void **)&A_layers[2].vm, NULL, A_layers[2].cuda_pbo_resource[0]);
  cudaGraphicsMapResources(1, &B_layers[1].cuda_pbo_resource[0], 0); cudaGraphicsResourceGetMappedPointer((void **)&B_layers[1].vm, NULL, B_layers[1].cuda_pbo_resource[0]);
  cudaGraphicsMapResources(1, &B_layers[2].cuda_pbo_resource[0], 0); cudaGraphicsResourceGetMappedPointer((void **)&B_layers[2].vm, NULL, B_layers[2].cuda_pbo_resource[0]);
  
  //the Isyn-current arrays
  cudaGraphicsMapResources(1, &A_layers[1].cuda_pbo_resource[1], 0); cudaGraphicsResourceGetMappedPointer((void **)&A_layers[1].isyn, NULL, A_layers[1].cuda_pbo_resource[1]);
  cudaGraphicsMapResources(1, &A_layers[2].cuda_pbo_resource[1], 0); cudaGraphicsResourceGetMappedPointer((void **)&A_layers[2].isyn, NULL, A_layers[2].cuda_pbo_resource[1]);
  cudaGraphicsMapResources(1, &B_layers[1].cuda_pbo_resource[1], 0); cudaGraphicsResourceGetMappedPointer((void **)&B_layers[1].isyn, NULL, B_layers[1].cuda_pbo_resource[1]);
  cudaGraphicsMapResources(1, &B_layers[2].cuda_pbo_resource[1], 0); cudaGraphicsResourceGetMappedPointer((void **)&B_layers[2].isyn, NULL, B_layers[2].cuda_pbo_resource[1]);

  //CA3 support
  cudaGraphicsMapResources(1, &C_layers[1].cuda_pbo_resource[0], 0); cudaGraphicsResourceGetMappedPointer((void **)&C_layers[1].vm, NULL, C_layers[1].cuda_pbo_resource[0]);
  cudaGraphicsMapResources(1, &C_layers[2].cuda_pbo_resource[0], 0); cudaGraphicsResourceGetMappedPointer((void **)&C_layers[2].vm, NULL, C_layers[2].cuda_pbo_resource[0]);
  cudaGraphicsMapResources(1, &C_layers[1].cuda_pbo_resource[1], 0); cudaGraphicsResourceGetMappedPointer((void **)&C_layers[1].isyn, NULL, C_layers[1].cuda_pbo_resource[1]);
  cudaGraphicsMapResources(1, &C_layers[2].cuda_pbo_resource[1], 0); cudaGraphicsResourceGetMappedPointer((void **)&C_layers[2].isyn, NULL, C_layers[2].cuda_pbo_resource[1]);


  int rf = R_AE;
  int rr = RADIUSV2;
  int A_lgn_rf = A_rfield_type;

  s_iB.en_periodic = 0;  //big-array input synbapses
  s_iS.en_periodic = 0;
  s_latB.en_periodic = 0;
  s_latS.en_periodic = 0;
  s_b2s.en_periodic = 0;
  s_s2br.en_periodic = 0;
  s_s2b.en_periodic = 0;
  s_iCA3.en_periodic = 0;
  s_ca3lat.en_periodic = 0;
  s_ca32ca1.en_periodic = 0;

  if ( pause_animation == 0 ) {
      for (int i = 0; i < DTS_PER_RENDER; ++i) {   //Each pass through the loop is one render every DTS_PER_RENDER DTs
						   //receptive field types: 0: zero 1:horzontal 2:vertical 3:backslash 4:forward slash 5:all excitatory 6:center-surround 
        //the first synapses kernel into a layer must use accumulate=false to reset.  Additional synapse kernels into a layer must use accumulate=true. L3_2_L2_synapseKernelLauncher has accumulate hard-coded true, should be 2nd
        I_synapseKernelLauncher      (A_cellLayer1, A_cellLayer2, A_synapse_i_pc,    W1,    s_iB, RADIUSI, false, false );  //layer1 onto equally sized layer2
        I_synapseKernelLauncher      (B_cellLayer1, B_cellLayer2, B_synapse_i_pc,    W4,    s_iS, RADIUSI, false, false );  //layer3 onto equally sized layer4
        P_synapseKernelLauncher      (A_cellLayer2, A_cellLayer2, A_synapse_pc_lateral, W1, s_latB, RADIUSP, true );  //big layer2<->layer2 lateral connections
        P_synapseKernelLauncher      (B_cellLayer2, B_cellLayer2, B_synapse_pc_lateral, W4, s_latS, RADIUSP, true );  //small layer2<->layer2 lateral connections
        b2s_synapseKernelLauncher(A_cellLayer2, B_cellLayer2, b2s_synapse, W4, s_b2s, RADIUSP );      //Big array onto small array
        s2b_synapseKernelLauncher(B_cellLayer2, A_cellLayer2, s2br_synapse, W4, W2, s_s2br, RADIUSP );      //small array onto big array reverse
        s2b_synapseKernelLauncher(B_cellLayer2, A_cellLayer2, s2b_synapse, W4, W2, s_s2b, RADIUSP );  //small array onto big array w/ intrinsic FO3 plus whatever RADUIS is used
												      
        I_synapseKernelLauncher      (C_cellLayer1, C_cellLayer2, C_synapse_i_pc,    W1,    s_iCA3, RADIUSI, false, false );  //layer3 onto equally sized layer4
        P_synapseKernelLauncher      (C_cellLayer2, C_cellLayer2, C_synapse_pc_lateral, W1, s_ca3lat,  RADIUSP, true );  //big layer2<->layer2 lateral connections
        P_synapseKernelLauncher      (C_cellLayer2, A_cellLayer2, ca3_2_ca1_synapse,    W1, s_ca32ca1, RADIUSP, true );  //big CA3 to CA1 cuing connections
														      
	//remember there are switches in the kernels triggered by layer number, e.g. tii spontanious firing current in layers 3, 13
        I_cellKernelLauncher(A_layers[1].vm, A_layers[1].isyn, A_cellLayer1, W1, A_loc, cell_switches1,  layer1_params, 1, A_stimulus_type, 0 ); //big input layer
        cellKernelLauncher2(A_layers[2].vm,  A_layers[2].isyn, A_cellLayer2, W2, A_loc, cell_switches2,  layer1_params, 2 ); //big pattern completion layer non-bursting
        I_cellKernelLauncher(B_layers[1].vm, B_layers[1].isyn, B_cellLayer1, W4, A_loc, cell_switches1,  layer1_params, 3, A_stimulus_type, 0 ); //small input layer
        cellKernelLauncher2(B_layers[2].vm,  B_layers[2].isyn, B_cellLayer2, W4, A_loc, cell_switches2,  layer1_params, 4 ); //small pattern completion layer

        I_cellKernelLauncher(C_layers[1].vm, C_layers[1].isyn, C_cellLayer1, W1, A_loc, cell_switches1,  layer1_params, 5, A_stimulus_type, 0 ); //big input layer
        cellKernelLauncher2(C_layers[2].vm,  C_layers[2].isyn, C_cellLayer2, W2, A_loc, cell_switches2,  layer1_params, 6 ); //big pattern completion layer non-bursting

      }
  }
  cudaGraphicsUnmapResources(1, &A_layers[1].cuda_pbo_resource[0], 0);
  cudaGraphicsUnmapResources(1, &A_layers[2].cuda_pbo_resource[0], 0);
  cudaGraphicsUnmapResources(1, &B_layers[1].cuda_pbo_resource[0], 0);
  cudaGraphicsUnmapResources(1, &B_layers[2].cuda_pbo_resource[0], 0);

  cudaGraphicsUnmapResources(1, &A_layers[1].cuda_pbo_resource[1], 0);
  cudaGraphicsUnmapResources(1, &A_layers[2].cuda_pbo_resource[1], 0);
  cudaGraphicsUnmapResources(1, &B_layers[1].cuda_pbo_resource[1], 0);
  cudaGraphicsUnmapResources(1, &B_layers[2].cuda_pbo_resource[1], 0);

  cudaGraphicsUnmapResources(1, &C_layers[1].cuda_pbo_resource[0], 0);
  cudaGraphicsUnmapResources(1, &C_layers[2].cuda_pbo_resource[0], 0);
  cudaGraphicsUnmapResources(1, &C_layers[1].cuda_pbo_resource[1], 0);
  cudaGraphicsUnmapResources(1, &C_layers[2].cuda_pbo_resource[1], 0);

}

void draw_texture( int w, int h) {
  glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
  glEnable(GL_TEXTURE_2D);
  glBegin(GL_QUADS);
  glTexCoord2f(0.0f, 0.0f); glVertex2f(0, 0);
  glTexCoord2f(0.0f, 1.0f); glVertex2f(0, h);
  glTexCoord2f(1.0f, 1.0f); glVertex2f(w, h);
  glTexCoord2f(1.0f, 0.0f); glVertex2f(w, 0);
  glEnd();
  glDisable(GL_TEXTURE_2D);
}


void display() {
  char title[128];

  render();

  glutSetWindow(A_layers[1].win[0]);  sprintf(title, "[%2.3f][%d][%d][%d%d%d%d]", SimTime, A_stim_state, A_counter, s_latB.en_syn, s_latS.en_syn, s_b2s.en_syn, s_s2b.en_syn); draw_texture( W1, W1); glutSetWindowTitle(title); glutPostRedisplay(); glutSwapBuffers(); //this one is necessary, can't be commented
  if ( enable_rendering ) {
      glutSetWindow(A_layers[2].win[0]);  sprintf(title, "[%2.3f][%d][%d][%d%d%d%d]", SimTime, A_stim_state, A_counter, s_latB.en_syn, s_latS.en_syn, s_b2s.en_syn, s_s2b.en_syn );                        draw_texture( W2, W2); glutSetWindowTitle(title); glutPostRedisplay(); glutSwapBuffers();
      glutSetWindow(B_layers[1].win[0]);  sprintf(title, "IVm" );                              draw_texture( W4, W4); glutSetWindowTitle(title); glutPostRedisplay(); glutSwapBuffers();
      glutSetWindow(B_layers[2].win[0]);  sprintf(title, "PVm" );                             draw_texture( W4, W4); glutSetWindowTitle(title); glutPostRedisplay(); glutSwapBuffers();

      glutSetWindow(A_layers[1].win[1]);  sprintf(title, "[%2.3f][%d][%d][%d%d%d%d]", SimTime, A_stim_state, A_counter, s_latB.en_syn, s_latS.en_syn, s_b2s.en_syn, s_s2b.en_syn);  draw_texture( W1, W1); glutSetWindowTitle(title); glutPostRedisplay(); glutSwapBuffers();
      //*glutSetWindow(A_layers[2].win[1]);  sprintf(title, "A PC Isyn" );                      draw_texture( W2, W2); glutSetWindowTitle(title); glutPostRedisplay(); glutSwapBuffers();
      glutSetWindow(B_layers[1].win[1]);  sprintf(title, "a");                              draw_texture( W4, W4); glutSetWindowTitle(title); glutPostRedisplay(); glutSwapBuffers();
      //*glutSetWindow(B_layers[2].win[1]);  sprintf(title, "PCsyn" );                             draw_texture( W4, W4); glutSetWindowTitle(title); glutPostRedisplay(); glutSwapBuffers();

      glutSetWindow(C_layers[1].win[0]);  sprintf(title, "[%d][%d][%d%d%d%d]", A_stim_state, A_counter, s_latB.en_syn, s_latS.en_syn, s_b2s.en_syn, s_s2b.en_syn); draw_texture( W1, W1); glutSetWindowTitle(title); glutPostRedisplay(); glutSwapBuffers();
      glutSetWindow(C_layers[2].win[0]);  sprintf(title, "T=%4.3f", SimTime);                        draw_texture( W2, W2); glutSetWindowTitle(title); glutPostRedisplay(); glutSwapBuffers();
      glutSetWindow(C_layers[1].win[1]);  sprintf(title, "BS[%d%d] SB[%d%d] SBR[%d%d]", s_b2s.en_learn,s_b2s.en_syn, s_s2b.en_learn,s_s2b.en_syn, s_s2br.en_learn,s_s2br.en_syn);  draw_texture( W1, W1); glutSetWindowTitle(title); glutPostRedisplay(); glutSwapBuffers();
      //*glutSetWindow(C_layers[2].win[1]);  sprintf(title, "CA3 PC Layer Isyn" );                        draw_texture( W2, W2); glutSetWindowTitle(title); glutPostRedisplay(); glutSwapBuffers();
  }

}
void display_nul() {}  //the work gets done in the primary display call.  This is a place-holder for all the other windows.


void initPixelBuffer( GLuint* pboPtr, GLuint* texPtr, cudaGraphicsResource** cuda_pbo_resourcePtr, int W) {
  glGenBuffers(1, pboPtr); glBindBuffer(GL_PIXEL_UNPACK_BUFFER, (GLuint) *pboPtr); glBufferData(GL_PIXEL_UNPACK_BUFFER, W*W*sizeof(GLubyte)* 4, 0, GL_STREAM_DRAW);
  glGenTextures(1, texPtr); glBindTexture(GL_TEXTURE_2D, *texPtr ); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  cudaGraphicsGLRegisterBuffer( cuda_pbo_resourcePtr, (GLuint) *pboPtr, cudaGraphicsMapFlagsWriteDiscard);
}

void exitfunc() {
    cudaGraphicsUnregisterResource(A_layers[1].cuda_pbo_resource[0]); glDeleteBuffers(1, &A_layers[1].pbo[0]); glDeleteTextures(1, &A_layers[1].tex[0]);
    cudaGraphicsUnregisterResource(A_layers[2].cuda_pbo_resource[0]); glDeleteBuffers(1, &A_layers[2].pbo[0]); glDeleteTextures(1, &A_layers[2].tex[0]);
}

int main(int argc, char** argv) {
  cell_switches1.en_stim = true;
  cell_switches1.en_noise = false;
  cell_switches1.en_theta = false;

  cell_switches2.en_stim = true;
  cell_switches2.en_noise = false;
  cell_switches2.en_theta = false;  //set to true for theta

  cudaMalloc((void **)&d_big_in_pat, W1*W1*sizeof( float ));
  cudaMalloc((void **)&d_small_in_pat, W4*W4*sizeof( float ));

  cudaMalloc((void **)&A_cellLayer1, W1*W1*sizeof( lif_data_type ));
  cudaMalloc((void **)&A_cellLayer2, W2*W2*sizeof( lif_data_type ));
  cudaMalloc((void **)&B_cellLayer1, W4*W4*sizeof( lif_data_type ));
  cudaMalloc((void **)&B_cellLayer2, W4*W4*sizeof( lif_data_type ));
  cudaMalloc((void **)&C_cellLayer1, W1*W1*sizeof( lif_data_type ));
  cudaMalloc((void **)&C_cellLayer2, W2*W2*sizeof( lif_data_type ));


  cudaMalloc((void **)&A_synapse_i_pc,       W2*W2*sizeof( L1_synapse_data_type ));   //layer 1->2 synapse group
  cudaMalloc((void **)&A_synapse_pc_lateral, W2*W2*sizeof( P_synapse_data_type ));   //layer 1->2 synapse group
  cudaMalloc((void **)&b2s_synapse, W4*W4*sizeof( P_synapse_data_type ));   //Big array onto small array
  cudaMalloc((void **)&s2br_synapse, W4*W4*sizeof( P_synapse_data_type ));   //small array onto big array reverse
  cudaMalloc((void **)&s2b_synapse, W4*W4*sizeof( P_synapse_data_type ));   //small array onto big array

  cudaMalloc((void **)&B_synapse_i_pc,       W4*W4*sizeof( L1_synapse_data_type ));   //layer 1->2 synapse group
  cudaMalloc((void **)&B_synapse_pc_lateral, W4*W4*sizeof( P_synapse_data_type ));   //layer 1->2 synapse group
  cudaMalloc((void **)&ca3_2_ca1_synapse, W1*W1*sizeof( P_synapse_data_type ));   //CA3 to CA1 full-sized PC layers

  cudaMalloc((void **)&C_synapse_i_pc,       W2*W2*sizeof( L1_synapse_data_type ));  //CA3 input to PC layer
  cudaMalloc((void **)&C_synapse_pc_lateral, W2*W2*sizeof( P_synapse_data_type ));   //CA3 lateral connections

  char fileName[100];
  int retCode;
  strcpy(fileName, "syn_l1_to_l2.txt");       retCode = loadSynParams( fileName, &syn_params_l1_l2 ) ;
  strcpy(fileName, "syn_common.txt");         retCode = loadSynParams( fileName, &syn_params_common ) ;

  generateReceptiveFields();

  resetSnaps(  A_synapse_i_pc,   W1, W1, syn_params_l1_l2,  1 );
  resetSnapsP( A_synapse_pc_lateral,   W1, W1, syn_params_l1_l2,  1 );
  resetSnapsP(  b2s_synapse,   W4, W4, syn_params_l1_l2,  1 );
  resetSnapsP(  s2br_synapse,   W4, W4, syn_params_l1_l2,  1 );
  resetSnapsP(  s2b_synapse,   W4, W4, syn_params_l1_l2,  1 );
  resetSnapsP(  ca3_2_ca1_synapse,   W1, W1, syn_params_l1_l2,  1 );

  resetSnaps(  B_synapse_i_pc,   W4, W4, syn_params_l1_l2,  1 );
  resetSnapsP( B_synapse_pc_lateral,   W4, W4, syn_params_l1_l2,  1 );

  resetNetwork();

  printInstructions();
  initGLUT(&argc, argv); 
  glutIdleFunc(idle);


  //display must be called only once.  The others must call display_nul
 
  glutSetWindow(A_layers[1].win[0]); glutKeyboardFunc(keyboard); initPixelBuffer( &A_layers[1].pbo[0], &A_layers[1].tex[0], &A_layers[1].cuda_pbo_resource[0], W1 );  gluOrtho2D(0, W1, W1, 0);  glutMouseFunc(mouse); glutMotionFunc(mouseDrag); glutDisplayFunc(display);
  glutSetWindow(A_layers[2].win[0]); glutKeyboardFunc(keyboard); initPixelBuffer( &A_layers[2].pbo[0], &A_layers[2].tex[0], &A_layers[2].cuda_pbo_resource[0], W2 );  gluOrtho2D(0, W2, W2, 0);  glutMouseFunc(mouse); glutMotionFunc(mouseDrag); glutDisplayFunc(display_nul);
  glutSetWindow(B_layers[1].win[0]); glutKeyboardFunc(keyboard); initPixelBuffer( &B_layers[1].pbo[0], &B_layers[1].tex[0], &B_layers[1].cuda_pbo_resource[0], W4 );  gluOrtho2D(0, W4, W4, 0);  glutMouseFunc(mouse); glutMotionFunc(mouseDrag); glutDisplayFunc(display_nul);
  glutSetWindow(B_layers[2].win[0]); glutKeyboardFunc(keyboard); initPixelBuffer( &B_layers[2].pbo[0], &B_layers[2].tex[0], &B_layers[2].cuda_pbo_resource[0], W4 );  gluOrtho2D(0, W4, W4, 0);  glutMouseFunc(mouse); glutMotionFunc(mouseDrag); glutDisplayFunc(display_nul);

  glutSetWindow(A_layers[1].win[1]); glutKeyboardFunc(keyboard); initPixelBuffer( &A_layers[1].pbo[1], &A_layers[1].tex[1], &A_layers[1].cuda_pbo_resource[1], W1 );  gluOrtho2D(0, W1, W1, 0);  glutMouseFunc(mouse); glutMotionFunc(mouseDrag); glutDisplayFunc(display_nul);
  glutSetWindow(A_layers[2].win[1]); glutKeyboardFunc(keyboard); initPixelBuffer( &A_layers[2].pbo[1], &A_layers[2].tex[1], &A_layers[2].cuda_pbo_resource[1], W2 );  gluOrtho2D(0, W2, W2, 0);  glutMouseFunc(mouse); glutMotionFunc(mouseDrag); glutDisplayFunc(display_nul);
  glutSetWindow(B_layers[1].win[1]); glutKeyboardFunc(keyboard); initPixelBuffer( &B_layers[1].pbo[1], &B_layers[1].tex[1], &B_layers[1].cuda_pbo_resource[1], W4 );  gluOrtho2D(0, W4, W4, 0);  glutMouseFunc(mouse); glutMotionFunc(mouseDrag); glutDisplayFunc(display_nul);
  glutSetWindow(B_layers[2].win[1]); glutKeyboardFunc(keyboard); initPixelBuffer( &B_layers[2].pbo[1], &B_layers[2].tex[1], &B_layers[2].cuda_pbo_resource[1], W4 );  gluOrtho2D(0, W4, W4, 0);  glutMouseFunc(mouse); glutMotionFunc(mouseDrag); glutDisplayFunc(display_nul);

  glutSetWindow(C_layers[1].win[0]); glutKeyboardFunc(keyboard); initPixelBuffer( &C_layers[1].pbo[0], &C_layers[1].tex[0], &C_layers[1].cuda_pbo_resource[0], W1 );  gluOrtho2D(0, W1, W1, 0);  glutMouseFunc(mouse); glutMotionFunc(mouseDrag); glutDisplayFunc(display_nul);
  glutSetWindow(C_layers[2].win[0]); glutKeyboardFunc(keyboard); initPixelBuffer( &C_layers[2].pbo[0], &C_layers[2].tex[0], &C_layers[2].cuda_pbo_resource[0], W1 );  gluOrtho2D(0, W1, W1, 0);  glutMouseFunc(mouse); glutMotionFunc(mouseDrag); glutDisplayFunc(display_nul);
  glutSetWindow(C_layers[1].win[1]); glutKeyboardFunc(keyboard); initPixelBuffer( &C_layers[1].pbo[1], &C_layers[1].tex[1], &C_layers[1].cuda_pbo_resource[1], W1 );  gluOrtho2D(0, W1, W1, 0);  glutMouseFunc(mouse); glutMotionFunc(mouseDrag); glutDisplayFunc(display_nul);
  glutSetWindow(C_layers[2].win[1]); glutKeyboardFunc(keyboard); initPixelBuffer( &C_layers[2].pbo[1], &C_layers[2].tex[1], &C_layers[2].cuda_pbo_resource[1], W1 );  gluOrtho2D(0, W1, W1, 0);  glutMouseFunc(mouse); glutMotionFunc(mouseDrag); glutDisplayFunc(display_nul);

  glutMainLoop();
  atexit(exitfunc);
  return 0;
}
