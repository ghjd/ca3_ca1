#!/usr/bin/env perl

use Cwd;
use File::Find;
use File::Spec;
use IO::File;
use Getopt::Long;
use strict;
use warnings;



my $cwd = getcwd();
my $fileName;

GetOptions(
		'in=s' => \$fileName 
);

print "[INFO] opening $fileName for reading.\n";
open( IN, "<$fileName" ) or die "Unable to open $fileName for reading.\n";


open( L1, ">Vm.txt" ) or die "Unable to open l1.txt for writing.\n";
open( L2, ">isyn.txt" ) or die "Unable to open l3.txt for writing.\n";
open( L3, ">ica.txt" ) or die "Unable to open l3.txt for writing.\n";
open( L4, ">Vms.txt" ) or die "Unable to open l3.txt for writing.\n";
open( L5, ">intensity.txt" ) or die "Unable to open intensity.txt for writing.\n";
open( L6, ">isyn_vs_intensity.txt" ) or die "Unable to open intensity.txt for writing.\n";

while (my $line = <IN> ) {
    if ( $line =~ m/^[a-z]+\s+-?[0-9]/ ){
	my @fields = split(/\s+/, $line);
	if ( $fields[0] eq "vm" ) { print L1 "$fields[1]\t$fields[2]\n"}
	if ( $fields[0] eq "isyn" ) { print L2 "$fields[1]\t$fields[2]\n"}
	if ( $fields[0] eq "ica" ) { print L3 "$fields[1]\t$fields[2]\n"}
	if ( $fields[0] eq "vms" ) { print L4 "$fields[1]\t$fields[2]\n"}
	if ( $fields[0] eq "intensity" ) { print L5 "$fields[1]\t$fields[2]\n"}
	if ( $fields[0] =~ m/blatz/ ) { print L6 "$fields[1]\t$fields[2]\n"}
    }
}
